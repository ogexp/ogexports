<?php

namespace App\Support;

use App\Models\User;

class SupplierMarket
{
    public const PAKISTAN = 'pakistan';

    public const INTERNATIONAL = 'international';

    public static function fromCountry(?string $country): string
    {
        return strtolower(trim((string) $country)) === 'pakistan'
            ? self::PAKISTAN
            : self::INTERNATIONAL;
    }

    public static function fromUser(?User $user): string
    {
        $user?->loadMissing('profile');

        return self::fromCountry($user?->profile?->country);
    }

    public static function values(): array
    {
        return [self::PAKISTAN, self::INTERNATIONAL];
    }
}
