<?php

require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use Illuminate\Support\Facades\Storage;

$origin = 'http://localhost:5000';
$base = 'http://127.0.0.1:8000';
$cookieFile = sys_get_temp_dir().DIRECTORY_SEPARATOR.'ogexport_docs_cookies.txt';
@unlink($cookieFile);

function req(string $method, string $url, $body, string $cookieFile, string $origin, array $extraHeaders = [], bool $rawBody = false): array
{
    $ch = curl_init($url);
    $headers = array_merge([
        'Accept: application/json',
        'Origin: '.$origin,
        'X-Requested-With: XMLHttpRequest',
    ], $extraHeaders);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_COOKIEJAR => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    return [
        'code' => $code,
        'headers' => substr((string) $raw, 0, $headerSize),
        'body' => substr((string) $raw, $headerSize),
    ];
}

function xsrfFromCookieFile(string $cookieFile): ?string
{
    if (! is_file($cookieFile)) {
        return null;
    }
    foreach (file($cookieFile) as $line) {
        if (str_starts_with($line, '#') || trim($line) === '') {
            continue;
        }
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 7 && $parts[5] === 'XSRF-TOKEN') {
            return urldecode($parts[6]);
        }
    }
    return null;
}

function corsLines(string $headers): void
{
    foreach (explode("\n", $headers) as $h) {
        if (stripos($h, 'Access-Control') !== false || stripos($h, 'HTTP/') === 0) {
            echo trim($h).PHP_EOL;
        }
    }
}

// Create a tiny test PDF on public disk
$relative = 'uploads/trade-documents/repro-test-'.time().'.pdf';
Storage::disk('public')->put($relative, "%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");
echo "stored file: ".$relative.' exists='.(Storage::disk('public')->exists($relative) ? 'yes' : 'no').PHP_EOL;

echo "=== CSRF ===".PHP_EOL;
req('GET', $base.'/sanctum/csrf-cookie', null, $cookieFile, $origin);
$xsrf = xsrfFromCookieFile($cookieFile);

echo "=== ADMIN LOGIN ===".PHP_EOL;
$login = req('POST', $base.'/api/auth/login', json_encode([
    'email' => 'ogadmin@ogexports.com',
    'password' => 'Password@123',
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$login['code'].PHP_EOL;
echo substr($login['body'], 0, 200).PHP_EOL;
$xsrf = xsrfFromCookieFile($cookieFile) ?: $xsrf;

echo "=== ADMIN POST shipment document ===".PHP_EOL;
$store = req('POST', $base.'/api/admin/shipments/1/documents', json_encode([
    'type' => 'Bill of Lading',
    'title' => 'Repro BL Test',
    'path' => $relative,
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$store['code'].PHP_EOL;
echo substr($store['body'], 0, 500).PHP_EOL;
corsLines($store['headers']);
$docId = null;
$decoded = json_decode($store['body'], true);
$docId = $decoded['data']['id'] ?? null;
echo "document id: ".$docId.PHP_EOL;

@unlink($cookieFile);
echo "=== BUYER CSRF ===".PHP_EOL;
req('GET', $base.'/sanctum/csrf-cookie', null, $cookieFile, $origin);
$xsrf = xsrfFromCookieFile($cookieFile);

echo "=== BUYER LOGIN ===".PHP_EOL;
$blogin = req('POST', $base.'/api/auth/login', json_encode([
    'email' => 'buyer@ogexports.com',
    'password' => 'Password@123',
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$blogin['code'].PHP_EOL;
$xsrf = xsrfFromCookieFile($cookieFile) ?: $xsrf;

echo "=== BUYER GET documents ===".PHP_EOL;
$list = req('GET', $base.'/api/buyer/documents?per_page=100', null, $cookieFile, $origin, [
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$list['code'].PHP_EOL;
echo substr($list['body'], 0, 800).PHP_EOL;
corsLines($list['headers']);

if ($docId) {
    echo "=== BUYER DOWNLOAD document {$docId} ===".PHP_EOL;
    $dl = req('GET', $base.'/api/buyer/documents/'.$docId.'/download', null, $cookieFile, $origin, [
        'X-XSRF-TOKEN: '.($xsrf ?? ''),
    ]);
    echo 'HTTP '.$dl['code'].PHP_EOL;
    echo 'body bytes: '.strlen($dl['body']).PHP_EOL;
    corsLines($dl['headers']);

    echo "=== BUYER VIEW document {$docId} ===".PHP_EOL;
    $view = req('GET', $base.'/api/buyer/documents/'.$docId.'/view', null, $cookieFile, $origin, [
        'X-XSRF-TOKEN: '.($xsrf ?? ''),
    ]);
    echo 'HTTP '.$view['code'].PHP_EOL;
    echo 'body bytes: '.strlen($view['body']).PHP_EOL;
    corsLines($view['headers']);
}

echo "=== BUYER GET shipments (docs nested) ===".PHP_EOL;
$ships = req('GET', $base.'/api/buyer/shipments?per_page=100', null, $cookieFile, $origin, [
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$ships['code'].PHP_EOL;
$shipBody = json_decode($ships['body'], true);
$first = $shipBody['data'][0] ?? $shipBody['data']['data'][0] ?? null;
if ($first) {
    echo 'shipment id='.$first['id'].' vessel='.($first['vessel'] ?? '').' docs='.count($first['trade_documents'] ?? []).PHP_EOL;
    echo 'fields: container='.($first['container'] ?? 'null').' line='.($first['shipping_line'] ?? 'null').' origin='.($first['origin'] ?? 'null').' dest='.($first['destination'] ?? 'null').PHP_EOL;
} else {
    echo substr($ships['body'], 0, 500).PHP_EOL;
}
corsLines($ships['headers']);
