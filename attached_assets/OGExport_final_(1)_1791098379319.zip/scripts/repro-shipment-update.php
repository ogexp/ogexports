<?php

require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$origin = 'http://localhost:5000';
$base = 'http://127.0.0.1:8000';
$cookieFile = sys_get_temp_dir().DIRECTORY_SEPARATOR.'ogexport_ship_cookies.txt';
@unlink($cookieFile);

function req(string $method, string $url, $body, string $cookieFile, string $origin, array $extraHeaders = []): array
{
    $ch = curl_init($url);
    $headers = array_merge([
        'Accept: application/json',
        'Origin: '.$origin,
        'X-Requested-With: XMLHttpRequest',
    ], $extraHeaders);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_COOKIEJAR => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    return [
        'code' => $code,
        'headers' => substr((string) $raw, 0, $headerSize),
        'body' => substr((string) $raw, $headerSize),
    ];
}

function xsrfFromCookieFile(string $cookieFile): ?string
{
    if (! is_file($cookieFile)) {
        return null;
    }
    foreach (file($cookieFile) as $line) {
        if (str_starts_with($line, '#') || trim($line) === '') {
            continue;
        }
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 7 && $parts[5] === 'XSRF-TOKEN') {
            return urldecode($parts[6]);
        }
    }
    return null;
}

function corsLines(string $headers): void
{
    foreach (explode("\n", $headers) as $h) {
        if (stripos($h, 'Access-Control') !== false || stripos($h, 'HTTP/') === 0) {
            echo trim($h).PHP_EOL;
        }
    }
}

echo "=== OPTIONS PUT /api/admin/shipments/1 ===".PHP_EOL;
$opt = req('OPTIONS', $base.'/api/admin/shipments/1', null, $cookieFile, $origin, [
    'Access-Control-Request-Method: PUT',
    'Access-Control-Request-Headers: content-type,accept,x-xsrf-token',
]);
echo 'HTTP '.$opt['code'].PHP_EOL;
corsLines($opt['headers']);

req('GET', $base.'/sanctum/csrf-cookie', null, $cookieFile, $origin);
$xsrf = xsrfFromCookieFile($cookieFile);

echo "=== ADMIN LOGIN ===".PHP_EOL;
$login = req('POST', $base.'/api/auth/login', json_encode([
    'email' => 'ogadmin@ogexports.com',
    'password' => 'Password@123',
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$login['code'].PHP_EOL;
$xsrf = xsrfFromCookieFile($cookieFile) ?: $xsrf;

echo "=== PUT shipment details + new milestone ===".PHP_EOL;
$put = req('PUT', $base.'/api/admin/shipments/1', json_encode([
    'vessel' => 'Maersk Kinloss',
    'container' => 'MSKU4829104',
    'shipping_line' => 'Maersk',
    'origin' => 'Port Qasim',
    'destination' => 'Jebel Ali, UAE',
    'etd' => '2026-07-23',
    'eta' => '2026-08-01',
    'status' => 'in-transit',
    'current_milestone' => 'In Transit',
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$put['code'].PHP_EOL;
$decoded = json_decode($put['body'], true);
$milestones = $decoded['data']['milestones'] ?? [];
echo 'current_milestone='.($decoded['data']['current_milestone'] ?? '').PHP_EOL;
echo 'milestones count='.count($milestones).PHP_EOL;
foreach ($milestones as $m) {
    echo ' - '.$m['label'].' @ '.($m['occurred_at'] ?? 'null').PHP_EOL;
}
corsLines($put['headers']);

@unlink($cookieFile);
req('GET', $base.'/sanctum/csrf-cookie', null, $cookieFile, $origin);
$xsrf = xsrfFromCookieFile($cookieFile);

echo "=== BUYER LOGIN ===".PHP_EOL;
req('POST', $base.'/api/auth/login', json_encode([
    'email' => 'buyer@ogexports.com',
    'password' => 'Password@123',
]), $cookieFile, $origin, [
    'Content-Type: application/json',
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
$xsrf = xsrfFromCookieFile($cookieFile) ?: $xsrf;

echo "=== BUYER GET shipments ===".PHP_EOL;
$get = req('GET', $base.'/api/buyer/shipments?per_page=100', null, $cookieFile, $origin, [
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo 'HTTP '.$get['code'].PHP_EOL;
$buyer = json_decode($get['body'], true);
$row = $buyer['data'][0] ?? null;
if ($row) {
    echo 'vessel='.$row['vessel'].' container='.$row['container'].' line='.$row['shipping_line'].PHP_EOL;
    echo 'origin='.$row['origin'].' dest='.$row['destination'].PHP_EOL;
    echo 'etd='.$row['etd'].' eta='.$row['eta'].' status='.$row['status'].PHP_EOL;
    echo 'current_milestone='.$row['current_milestone'].PHP_EOL;
    echo 'milestones='.count($row['milestones'] ?? []).PHP_EOL;
    foreach (($row['milestones'] ?? []) as $m) {
        echo ' - '.$m['label'].' @ '.($m['occurred_at'] ?? 'null').PHP_EOL;
    }
} else {
    echo substr($get['body'], 0, 400).PHP_EOL;
}
corsLines($get['headers']);

echo "=== OPTIONS GET /api/buyer/documents ===".PHP_EOL;
$optDoc = req('OPTIONS', $base.'/api/buyer/documents', null, $cookieFile, $origin, [
    'Access-Control-Request-Method: GET',
    'Access-Control-Request-Headers: accept,x-requested-with',
]);
echo 'HTTP '.$optDoc['code'].PHP_EOL;
corsLines($optDoc['headers']);
