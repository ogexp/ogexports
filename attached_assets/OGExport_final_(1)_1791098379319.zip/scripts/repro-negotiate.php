<?php

require __DIR__.'/../vendor/autoload.php';
$app = require __DIR__.'/../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use Illuminate\Support\Facades\DB;

DB::table('quotations')->where('id', 1)->update(['status' => 'sent']);
echo "quotation status: ".DB::table('quotations')->where('id', 1)->value('status').PHP_EOL;

$origin = 'http://localhost:5000';
$base = 'http://127.0.0.1:8000';
$cookieFile = sys_get_temp_dir().DIRECTORY_SEPARATOR.'ogexport_repro_cookies.txt';
@unlink($cookieFile);

function req(string $method, string $url, ?string $body, string $cookieFile, string $origin, array $extraHeaders = []): array
{
    $ch = curl_init($url);
    $headers = array_merge([
        'Accept: application/json',
        'Origin: '.$origin,
        'X-Requested-With: XMLHttpRequest',
    ], $extraHeaders);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_COOKIEJAR => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => $body,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    return [
        'code' => $code,
        'err' => $err,
        'headers' => substr((string) $raw, 0, $headerSize),
        'body' => substr((string) $raw, $headerSize),
    ];
}

function xsrfFromCookieFile(string $cookieFile): ?string
{
    if (! is_file($cookieFile)) {
        return null;
    }
    foreach (file($cookieFile) as $line) {
        if (str_starts_with($line, '#') || trim($line) === '') {
            continue;
        }
        $parts = preg_split('/\s+/', trim($line));
        if (count($parts) >= 7 && $parts[5] === 'XSRF-TOKEN') {
            return urldecode($parts[6]);
        }
    }
    return null;
}

echo "=== CSRF ===".PHP_EOL;
$csrf = req('GET', $base.'/sanctum/csrf-cookie', null, $cookieFile, $origin);
echo "HTTP ".$csrf['code'].PHP_EOL;
$xsrf = xsrfFromCookieFile($cookieFile);
echo "XSRF: ".($xsrf ? 'yes' : 'no').PHP_EOL;

echo "=== LOGIN ===".PHP_EOL;
$login = req(
    'POST',
    $base.'/api/auth/login',
    json_encode(['email' => 'buyer@ogexports.com', 'password' => 'Password@123']),
    $cookieFile,
    $origin,
    [
        'Content-Type: application/json',
        'X-XSRF-TOKEN: '.($xsrf ?? ''),
    ]
);
echo "HTTP ".$login['code'].PHP_EOL;
echo substr($login['body'], 0, 400).PHP_EOL;
$xsrf = xsrfFromCookieFile($cookieFile) ?: $xsrf;

echo "=== GET messages ===".PHP_EOL;
$get = req('GET', $base.'/api/buyer/quotations/1/messages', null, $cookieFile, $origin, [
    'X-XSRF-TOKEN: '.($xsrf ?? ''),
]);
echo "HTTP ".$get['code'].PHP_EOL;
echo substr($get['body'], 0, 500).PHP_EOL;
foreach (explode("\n", $get['headers']) as $h) {
    if (stripos($h, 'Access-Control') !== false || stripos($h, 'HTTP/') === 0) {
        echo trim($h).PHP_EOL;
    }
}

echo "=== POST message ===".PHP_EOL;
$post = req(
    'POST',
    $base.'/api/buyer/quotations/1/messages',
    json_encode(['body' => 'our target price is 1620$/MT']),
    $cookieFile,
    $origin,
    [
        'Content-Type: application/json',
        'X-XSRF-TOKEN: '.($xsrf ?? ''),
    ]
);
echo "HTTP ".$post['code'].PHP_EOL;
echo substr($post['body'], 0, 800).PHP_EOL;
foreach (explode("\n", $post['headers']) as $h) {
    if (stripos($h, 'Access-Control') !== false || stripos($h, 'HTTP/') === 0) {
        echo trim($h).PHP_EOL;
    }
}

echo "=== OPTIONS preflight ===".PHP_EOL;
$opt = req('OPTIONS', $base.'/api/buyer/quotations/1/messages', null, $cookieFile, $origin, [
    'Access-Control-Request-Method: POST',
    'Access-Control-Request-Headers: content-type,accept,x-xsrf-token,x-requested-with',
]);
echo "HTTP ".$opt['code'].PHP_EOL;
foreach (explode("\n", $opt['headers']) as $h) {
    if (stripos($h, 'Access-Control') !== false || stripos($h, 'HTTP/') === 0) {
        echo trim($h).PHP_EOL;
    }
}
