# Hostinger API deploy checklist (api.ogexports.co)
#
# Run from project root after uploading code:
#   1. Point the api.ogexports.co domain document root to /public (preferred)
#      OR keep project root and rely on root .htaccess -> public/
#   2. Copy .env.production.example to .env on the server and fill APP_KEY + DB_*
#   3. composer install --no-dev --optimize-autoloader
#   4. Ensure storage/ and bootstrap/cache/ are writable (775)
#   5. php artisan migrate --force
#   6. php artisan config:clear && php artisan cache:clear && php artisan route:clear
#   7. Open https://api.ogexports.co/boot-check.php then /api/health
#   8. Delete public/boot-check.php when healthy

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "Checking local prerequisites..."
if (-not (Test-Path "vendor\autoload.php")) {
    Write-Host "FAIL: vendor/ missing. Run: composer install --no-dev --optimize-autoloader"
    exit 1
}
if (-not (Test-Path ".env.production.example")) {
    Write-Host "FAIL: .env.production.example missing"
    exit 1
}

Write-Host "OK: vendor present"
Write-Host "OK: .env.production.example present"
Write-Host ""
Write-Host "Production .env must include:"
Write-Host "  APP_URL=https://api.ogexports.co"
Write-Host "  FRONTEND_URL=https://ogexports.co"
Write-Host "  SESSION_DOMAIN=.ogexports.co"
Write-Host "  SESSION_SECURE_COOKIE=true"
Write-Host "  SESSION_SAME_SITE=lax"
Write-Host "  SANCTUM_STATEFUL_DOMAINS=ogexports.co,www.ogexports.co,api.ogexports.co"
Write-Host "  APP_KEY=base64:..."
Write-Host "  DB_* for Hostinger MySQL"
Write-Host "  MAINT_TOKEN=<long-random-secret>  # for /api/maint/* when SSH is unavailable"
Write-Host ""
Write-Host "Sanctum CSRF / CORS:"
Write-Host "  - CSRF cookie route is registered in routes/web.php (config/sanctum.php has routes=>false)."
Write-Host "  - Do NOT run php artisan route:cache unless that web.php route is present."
Write-Host "  - Prefer: php artisan optimize:clear  (or route:clear + config:clear)."
Write-Host "  - ogexports.co must NOT emit Access-Control-Allow-Origin (disable Hostinger CDN CORS on SPA)."
Write-Host "  - Only api.ogexports.co (Laravel HandleCors) should set CORS for SPA origins."
Write-Host "  - If csrf-cookie intermittently returns 500 WITHOUT CORS headers: Hostinger hcdn edge bug."
Write-Host "    Purge CDN for api.ogexports.co or DISABLE CDN on the API domain (recommended)."
Write-Host "    See storage/app/SANCTUM_CORS_CDN_NOTES.md"
Write-Host ""
Write-Host "If MAINT_TOKEN/.env changes are ignored, delete bootstrap/cache/config.php via File Manager."
Write-Host ""
Write-Host "After upload, verify:"
Write-Host "  curl -H `"Origin: https://ogexports.co`" https://api.ogexports.co/boot-check.php"
Write-Host "  curl -H `"Origin: https://ogexports.co`" https://api.ogexports.co/api/health"
Write-Host "  curl -sI -H `"Origin: https://ogexports.co`" -H `"X-Requested-With: XMLHttpRequest`" https://api.ogexports.co/sanctum/csrf-cookie"
Write-Host "  # Repeat the csrf-cookie curl several times; all should be 204 (not intermittent 500)."
Write-Host "  curl `"https://api.ogexports.co/api/maint/status?token=YOUR_MAINT_TOKEN`""
Write-Host "  # If contact_persons is missing and SSH is unavailable:"
Write-Host "  curl `"https://api.ogexports.co/api/maint/migrate?token=YOUR_MAINT_TOKEN`""
Write-Host "  # Or run scripts/create-contact-persons.sql in Hostinger phpMyAdmin"
Write-Host ""
Write-Host "=== Buyer portal fix deploy (quotations / documents / shipments) ==="
Write-Host "On api.ogexports.co (SSH or Hostinger terminal), from the API project root:"
Write-Host "  composer install --no-dev --optimize-autoloader"
Write-Host "  php artisan migrate --force"
Write-Host "  php artisan storage:link"
Write-Host "  php artisan config:clear"
Write-Host "  php artisan cache:clear"
Write-Host "  php artisan route:clear"
Write-Host "  php artisan view:clear"
Write-Host ""
Write-Host "Browser fallback (no SSH): set MAINT_TOKEN in server .env, then open:"
Write-Host "  https://api.ogexports.co/api/maint/migrate?token=YOUR_MAINT_TOKEN"
Write-Host "  https://api.ogexports.co/api/maint/cache-clear?token=YOUR_MAINT_TOKEN"
Write-Host "  https://api.ogexports.co/api/maint/status?token=YOUR_MAINT_TOKEN"
Write-Host ""
Write-Host "Critical: migrate --force creates quotation_messages (fixes buyer Negotiate Server Error)."
Write-Host "Also creates contact_persons (fixes buyer company contact save 503)."
Write-Host "storage:link is required so buyer Trade Documents can view/download uploaded files."
Write-Host ""
Write-Host "Frontend (ogexports.co): rebuild locally then upload frontend/build contents:"
Write-Host "  cd frontend"
Write-Host "  # ensure .env.production has VITE_API_URL=https://api.ogexports.co"
Write-Host "  npm ci"
Write-Host "  npm run build"
Write-Host "  # upload frontend/build/* to the ogexports.co document root"
Write-Host ""
Write-Host "Smoke tests (replace COOKIE/XSRF after a real browser login):"
Write-Host "  curl -s -H `"Origin: https://ogexports.co`" -H `"Accept: application/json`" https://api.ogexports.co/api/health"
Write-Host "  # OPTIONS preflight negotiate:"
Write-Host "  curl -s -D - -o NUL -X OPTIONS https://api.ogexports.co/api/buyer/quotations/1/messages \"
Write-Host "    -H `"Origin: https://ogexports.co`" -H `"Access-Control-Request-Method: POST`" \"
Write-Host "    -H `"Access-Control-Request-Headers: content-type,accept,x-xsrf-token`""
Write-Host "  # After buyer login in browser DevTools, POST counter-offer should return 201 (not 500)."
Write-Host "  # GET /api/buyer/documents should list docs uploaded via admin Shipments/Orders Docs."
Write-Host "  # GET /api/buyer/shipments should show vessel/container/shipping_line/origin/destination/etd/eta from DB."
