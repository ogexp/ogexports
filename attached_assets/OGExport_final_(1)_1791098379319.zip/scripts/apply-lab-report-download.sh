#!/bin/bash
# Apply product lab-report download endpoint on Hostinger laravel_api.
# Usage (from SSH session already in laravel_api, or):
#   bash scripts/apply-lab-report-download.sh
set -euo pipefail

ROOT="${1:-/home/u133241207/domains/ogexports.co/public_html/laravel_api}"
cd "$ROOT"

CTRL="app/Http/Controllers/Api/Public/ProductController.php"
ROUTE_FILE="routes/api.php"

cp -a "$CTRL" "$CTRL.bak-labreport-$(date +%Y%m%d%H%M%S)"
cp -a "$ROUTE_FILE" "$ROUTE_FILE.bak-labreport-$(date +%Y%m%d%H%M%S)"

# Controller is expected to already be uploaded to this path, or use companion .b64 file.
if [ -f "scripts/ProductController.b64.txt" ]; then
  base64 -d scripts/ProductController.b64.txt > "$CTRL"
  echo "Wrote $CTRL from scripts/ProductController.b64.txt"
elif [ -f "ProductController.b64.txt" ]; then
  base64 -d ProductController.b64.txt > "$CTRL"
  echo "Wrote $CTRL from ProductController.b64.txt"
else
  echo "ERROR: upload ProductController.php or ProductController.b64.txt first"
  exit 1
fi

if ! grep -q "products/{slug}/lab-report" "$ROUTE_FILE"; then
  # Insert lab-report route immediately before the product show route.
  awk '
    /Route::get\(\x27\/products\/\{slug\}\x27, \[PublicProductController::class, \x27show\x27\]\);/ && !done {
      print "Route::get('\''/products/{slug}/lab-report'\'', [PublicProductController::class, '\''downloadLabReport'\'']);"
      done=1
    }
    { print }
  ' "$ROUTE_FILE" > "$ROUTE_FILE.tmp"
  mv "$ROUTE_FILE.tmp" "$ROUTE_FILE"
  echo "Inserted lab-report route into $ROUTE_FILE"
else
  echo "lab-report route already present"
fi

php artisan optimize:clear
php artisan route:list --path=products
echo "DONE — verify: curl -I https://api.ogexports.co/api/products/premium-basmati-rice/lab-report"
