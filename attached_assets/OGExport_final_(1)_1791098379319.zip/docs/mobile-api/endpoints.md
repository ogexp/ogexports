# Mobile investor endpoints

Paths are relative to `/api`. **Auth** column: Public, or Bearer (Sanctum).

Derived from the Flutter repositories:

- [`auth_repository.dart`](../../Mobile_app/og_investor/lib/features/auth/data/auth_repository.dart)
- [`investor_repository.dart`](../../Mobile_app/og_investor/lib/features/investor/data/investor_repository.dart)

---

## Setup / bootstrap

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/health` | Public | `{ "status": "ok", "app": "OGExport" }` |
| GET | `/mobile/v1/bootstrap` | Public (+ optional Bearer) | Module flags, currencies, auth paths; with Bearer adds `user.default_currency`, `has_default_bank_account` |

---

## Auth

See [authentication.md](authentication.md) for request/response details.

| Method | Path | Auth | Key body |
|--------|------|------|----------|
| POST | `/auth/register` | Public | `name`, `email`, `password`, `password_confirmation`, `account_type=investor` |
| POST | `/auth/mobile/login` | Public | `email`, `password`, `device_name?` |
| POST | `/auth/mobile/verify-email` | Public | `email`, `code`, `device_name?` |
| POST | `/auth/mobile/2fa/verify` | Public | `token`, `code`, `device_name?` |
| POST | `/auth/resend-verification` | Public | `email` |
| POST | `/auth/forgot-password` | Public | `email` |
| POST | `/auth/verify-reset-otp` | Public | `email`, `code` |
| POST | `/auth/reset-password` | Public | `email`, `password`, `password_confirmation` |
| POST | `/auth/mobile/logout` | Bearer | — |
| POST | `/mobile/v1/auth/*` | same | Aliases of mobile auth routes |

---

## Profile / settings

| Method | Path | Auth | Key body / query | Success shape |
|--------|------|------|------------------|---------------|
| GET | `/me` | Bearer | — | User resource |
| PUT | `/me` | Bearer | profile fields | User resource |
| PUT | `/me/password` | Bearer | `current_password`, `password`, `password_confirmation` | message |
| GET | `/investor/profile` | Bearer + investor | — | `{ data: profile }` |
| PUT | `/investor/profile` | Bearer + investor | name/phone/country/`bank_accounts` | `{ data }` |
| GET | `/investor/security/transaction-password` | Bearer + investor | — | status flags |
| POST | `/investor/security/transaction-password/set` | Bearer + investor | `password`, `password_confirmation` | message |
| POST | `/investor/security/transaction-password/reset` | Bearer + investor | `current_password`, `password`, `password_confirmation` | message |
| GET | `/investor/kyc` | Bearer + investor | `per_page?` | paginated applications |
| POST | `/investor/kyc` | Bearer + investor | `type`, `country?`, `payload?`, `documents?` | application |
| GET | `/settings` | Public | — | site settings |

---

## Dashboard / home

| Method | Path | Auth | Success shape |
|--------|------|------|---------------|
| GET | `/investor/dashboard` | Bearer + investor | `{ data: { summary, wallet, ... } }` |

---

## Invest

| Method | Path | Auth | Key body / query | Success shape |
|--------|------|------|------------------|---------------|
| GET | `/investor/projects` | Bearer + investor | `status?`, `type?`, `per_page?` | paginated projects |
| GET | `/investor/projects/{id}` | Bearer + investor | — | project resource |
| POST | `/investor/projects/{id}/invest` | Bearer + investor | `{ "amount": number }` | investment result (KYC gate) |
| GET | `/investor/investments` | Bearer + investor | filters / `per_page?` | paginated list |
| GET | `/investor/investments/{id}` | Bearer + investor | — | investment detail |
| GET | `/investor/investments/{id}/pdf` | Bearer + investor | — | PDF binary |
| GET | `/investor/facility-content/{type}` | Bearer + investor | type e.g. feed/ricemill | content payload |
| GET | `/investor/reports` | Bearer + investor | — | report list |
| POST | `/investor/reports` | Bearer + investor | report params | generated report |
| GET | `/investor/reports/{id}/download` | Bearer + investor | — | file download |

---

## Wallet

| Method | Path | Auth | Key body / query | Success shape |
|--------|------|------|------------------|---------------|
| GET | `/investor/wallet` | Bearer + investor | — | balances / currency |
| GET | `/investor/wallet/transactions` | Bearer + investor | `page?` | paginated ledger |
| GET | `/investor/wallet/exchange-rates` | Bearer + investor | — | rates |
| GET | `/investor/deposit-options` | Bearer + investor | — | options list |
| GET | `/investor/payment-bank-accounts` | Bearer + investor | — | platform bank accounts for transfers |
| GET | `/investor/deposits` | Bearer + investor | `status?`, `per_page?` | paginated deposits |
| POST | `/investor/deposits` | Bearer + investor | see below | **201** deposit |
| GET | `/investor/deposits/{id}` | Bearer + investor | — | deposit |
| GET | `/investor/deposits/{id}/pdf` | Bearer + investor | — | PDF |
| GET | `/investor/withdrawals` | Bearer + investor | `status?` | paginated |
| POST | `/investor/withdrawals/otp/send` | Bearer + investor | — | OTP emailed |
| POST | `/investor/withdrawals` | Bearer + investor | see below | **201** withdrawal |
| GET | `/investor/withdrawals/{id}` | Bearer + investor | — | withdrawal |
| GET | `/investor/withdrawals/{id}/pdf` | Bearer + investor | — | PDF |

### Deposit body (mobile-friendly)

```json
{
  "amount": 250,
  "currency": "USD",
  "bank_account_id": 1,
  "reference": "optional bank transfer ref",
  "proof_path": "optional path from POST /uploads"
}
```

- `currency` is **optional** — defaults to the investor wallet currency.
- `reference` is accepted as an alias of `bank_reference`.

### Withdrawal body (mobile-friendly)

```json
{
  "amount": 100,
  "otp": "888777",
  "transaction_password": "your-tx-password",
  "bank_details": {
    "bank_name": "Emirates NBD",
    "account_holder": "...",
    "account_number": "...",
    "iban": "...",
    "swift": "...",
    "branch": "..."
  }
}
```

- `bank_details` is **optional** — if omitted, the API uses the profile default bank account.
- If no bank account is configured: **422** on `bank_details` with message to add one in Settings.

---

## Products (public)

| Method | Path | Auth | Query | Success shape |
|--------|------|------|-------|---------------|
| GET | `/products` | Public | `search?`, `per_page?` | product list |
| GET | `/products/{slug}` | Public | — | product detail |

---

## Shared (notifications, support, messages, uploads)

Used lightly by the Flutter app today; full write APIs exist for later wiring.

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/investor/notifications` | Bearer + investor | list |
| GET | `/investor/notifications/unread-count` | Bearer + investor | count |
| POST | `/investor/notifications/read-all` | Bearer + investor | mark all |
| POST | `/investor/notifications/{id}/read` | Bearer + investor | mark one |
| GET | `/messages/unread-count` | Bearer | badge |
| GET | `/conversations/with-admin` | Bearer | ensure/fetch admin thread |
| GET | `/conversations` | Bearer | list |
| POST | `/conversations` | Bearer | create |
| GET | `/conversations/{id}/messages` | Bearer | messages |
| POST | `/conversations/{id}/messages` | Bearer | send |
| POST | `/conversations/{id}/read` | Bearer | mark read |
| GET | `/support/tickets` | Bearer | list |
| POST | `/support/tickets` | Bearer | create |
| GET | `/support/tickets/{id}` | Bearer | show |
| POST | `/support/tickets/{id}/reply` | Bearer | reply |
| POST | `/uploads` | Bearer | multipart `file`, optional `category` / `folder` → path for deposits/KYC |
