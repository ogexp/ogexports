# OG Exports — Mobile Investor API

REST API used by the Flutter investor app ([`Mobile_app/og_investor`](../../Mobile_app/og_investor)).

## Base URL

| Environment | Base URL |
|-------------|----------|
| Local (Laragon) | `http://ogexport_final.test/api` |
| Local (`artisan serve`) | `http://127.0.0.1:8000/api` |

All paths in this docs set are relative to that base (for example `/auth/mobile/login` → `http://ogexport_final.test/api/auth/mobile/login`).

## Auth model

- **Web SPA:** Sanctum session cookies + CSRF
- **Mobile (Flutter):** Sanctum **personal access tokens** (`Authorization: Bearer {token}`)
- Prefer the mobile auth endpoints under `/auth/mobile/*` (or aliases under `/mobile/v1/auth/*`) so the client never depends on cookies

## Module map (Flutter tabs)

| App tab | Primary API groups |
|---------|-------------------|
| Home | `GET /investor/dashboard` |
| Invest | `/investor/projects`, `/investor/investments`, `/investor/facility-content/{type}` |
| Wallet | `/investor/wallet`, deposits, withdrawals |
| Products | `GET /products`, `GET /products/{slug}` (public) |
| Settings | `/investor/profile`, KYC, transaction password |
| Other | notifications, support tickets, conversations |

## Docs in this folder

- [authentication.md](authentication.md) — login, 2FA, email verify, logout flows
- [endpoints.md](endpoints.md) — endpoint tables matching the shipped Flutter repositories
- [errors-and-conventions.md](errors-and-conventions.md) — validation errors, pagination, downloads

## Postman

Import:

1. [`postman/OG-Exports-Mobile-Investor.postman_collection.json`](../../postman/OG-Exports-Mobile-Investor.postman_collection.json)
2. [`postman/OG-Exports-Mobile-Investor.local.postman_environment.json`](../../postman/OG-Exports-Mobile-Investor.local.postman_environment.json)

Select the **OG Exports Mobile Investor (local)** environment, then run **Auth → Mobile Login** (or 2FA verify) to populate `bearer_token`.

## Bootstrap

`GET /mobile/v1/bootstrap` returns module flags, supported currencies, auth path hints, and (when a Bearer token is sent) the user’s default currency and whether a default bank account exists.

## Demo credentials (local)

| Field | Value |
|-------|-------|
| Email | `investor@ogexports.com` |
| Password | `12345678` |
| Dev OTP | `888777` (`APP_DEBUG=true`) |
