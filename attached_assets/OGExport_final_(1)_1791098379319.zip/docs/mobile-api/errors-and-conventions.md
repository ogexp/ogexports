# Errors and conventions

## Headers

```http
Accept: application/json
Content-Type: application/json
Authorization: Bearer {token}   # when authenticated
```

For file uploads (`POST /uploads`), use `multipart/form-data` (omit JSON `Content-Type`).

## Validation errors (422)

Laravel standard shape:

```json
{
  "message": "The amount field is required.",
  "errors": {
    "amount": ["The amount field is required."]
  }
}
```

The Flutter client surfaces the first message from `errors` when present.

## Unauthorized (401)

Missing/invalid Bearer token on protected routes. Body is typically:

```json
{ "message": "Unauthenticated." }
```

## Forbidden / pending verification (403)

Email not verified on mobile login returns **403** with `requires_verification: true` (see [authentication.md](authentication.md)). Role/module middleware may also return 403 for non-investors or when the investment module is disabled.

## Pagination

List endpoints that return Laravel paginators accept:

| Query | Default | Notes |
|-------|---------|-------|
| `page` | `1` | page number |
| `per_page` | controller default | capped server-side |

Typical JSON:

```json
{
  "data": [ ... ],
  "current_page": 1,
  "last_page": 3,
  "per_page": 15,
  "total": 40
}
```

Some resources wrap items as `{ "data": [ ... ] }` (API Resources). The Flutter `_listFrom` helper accepts both shapes.

## Success envelopes

| Pattern | Example |
|---------|---------|
| `{ data: ... }` | dashboard, profile, wallet |
| bare resource / paginator | many list endpoints |
| `{ message, data }` | deposits/withdrawals create (**201**) |
| `{ message, token, user, token_type }` | mobile login / verify |

## PDF and file downloads

Routes such as:

- `GET /investor/deposits/{id}/pdf`
- `GET /investor/withdrawals/{id}/pdf`
- `GET /investor/investments/{id}/pdf`
- `GET /investor/reports/{id}/download`
- `GET /investor/projects/{id}/documents/{documentId}/download`

require Bearer auth and return binary (`application/pdf` or octet-stream). In Postman, use **Send and Download**.

## Currencies

- Supported list: from `GET /mobile/v1/bootstrap` → `supported_currencies` (config `currency.supported`).
- Wallet currency drives deposit default and withdrawal bank currency overwrite for PKR users.

## Local OTP

When `APP_DEBUG=true`, OTP-related responses may include `dev_otp` (default `888777`). Never rely on this in production builds.
