# Mobile authentication

Mobile clients use Sanctum **Bearer tokens**. Do not use the web `POST /auth/login` endpoint for Flutter — it creates a session cookie.

## Canonical endpoints

| Method | Path | Auth |
|--------|------|------|
| POST | `/auth/register` | Public |
| POST | `/auth/mobile/login` | Public |
| POST | `/auth/mobile/verify-email` | Public |
| POST | `/auth/mobile/2fa/verify` | Public |
| POST | `/auth/resend-verification` | Public |
| POST | `/auth/forgot-password` | Public |
| POST | `/auth/verify-reset-otp` | Public |
| POST | `/auth/reset-password` | Public |
| POST | `/auth/mobile/logout` | Bearer |
| GET | `/me` | Bearer |

## Equivalent aliases (`/mobile/v1`)

| Alias | Same handler as |
|-------|-----------------|
| `POST /mobile/v1/auth/login` | `/auth/mobile/login` |
| `POST /mobile/v1/auth/verify-email` | `/auth/mobile/verify-email` |
| `POST /mobile/v1/auth/2fa/verify` | `/auth/mobile/2fa/verify` |
| `POST /mobile/v1/auth/logout` | `/auth/mobile/logout` |

The Flutter app uses the **canonical** `/auth/mobile/*` paths.

---

## Register

```http
POST /auth/register
Content-Type: application/json

{
  "name": "Jane Investor",
  "email": "jane@example.com",
  "password": "Password1!",
  "password_confirmation": "Password1!",
  "account_type": "investor",
  "phone": "+971500000000",
  "country": "United Arab Emirates",
  "company_name": "Jane Capital"
}
```

**201** — email verification required:

```json
{
  "message": "...",
  "requires_verification": true,
  "email": "jane@example.com",
  "masked_email": "j***@example.com",
  "dev_otp": "888777"
}
```

`dev_otp` is only present when `APP_DEBUG=true`.

---

## Login (success)

```http
POST /auth/mobile/login
Content-Type: application/json

{
  "email": "investor@ogexports.com",
  "password": "12345678",
  "device_name": "flutter_investor"
}
```

**200** — token issued:

```json
{
  "message": "Logged in successfully.",
  "user": { "id": 1, "email": "...", "roles": ["investor"] },
  "token": "1|xxxxxxxx",
  "token_type": "Bearer",
  "redirect": "/invest"
}
```

Send on subsequent requests:

```http
Authorization: Bearer 1|xxxxxxxx
Accept: application/json
```

---

## Login → email verification pending

**403**:

```json
{
  "requires_verification": true,
  "email": "jane@example.com",
  "masked_email": "j***@example.com",
  "message": "Please verify your email before signing in.",
  "dev_otp": "888777"
}
```

Then call:

```http
POST /auth/mobile/verify-email

{
  "email": "jane@example.com",
  "code": "888777",
  "device_name": "flutter_investor"
}
```

**200** returns `token` + `user` (same shape as login success).

Resend: `POST /auth/resend-verification` with `{ "email": "..." }`.

---

## Login → 2FA required

**200** (challenge, not yet logged in):

```json
{
  "requires_2fa": true,
  "token": "challenge-token-uuid",
  "email": "i***@ogexports.com",
  "message": "...",
  "dev_otp": "888777"
}
```

Complete with:

```http
POST /auth/mobile/2fa/verify

{
  "token": "challenge-token-uuid",
  "code": "888777",
  "device_name": "flutter_investor"
}
```

**200** returns Sanctum `token` + `user`.

---

## Invalid credentials / blocked

**422** Laravel validation:

```json
{
  "message": "The provided credentials are incorrect.",
  "errors": {
    "email": ["The provided credentials are incorrect."]
  }
}
```

Also used for suspended / inactive accounts and disabled investment module.

---

## Password reset

1. `POST /auth/forgot-password` `{ "email": "..." }` — may include `dev_otp`
2. `POST /auth/verify-reset-otp` `{ "email", "code" }`
3. `POST /auth/reset-password` `{ "email", "password", "password_confirmation" }`

---

## Logout

```http
POST /auth/mobile/logout
Authorization: Bearer {token}
```

**200** `{ "message": "Logged out successfully." }` — revokes the current personal access token only.
