# Redeploy: Request Quotation fix (POST /api/contact)

Use this checklist after pulling/uploading the latest code from this repo.

## Quick Hostinger SSH deploy (recommended)

1. Upload to `/home/u133241207/domains/ogexports.co/public_html/laravel_api/`:
   - `storage/app/quotation-contact-deploy.b64.json` (regenerate with `php storage/app/build-quotation-deploy-bundle.php` if PHP sources changed)
   - `storage/app/deploy-quotation-contact-on-prod.sh`
2. SSH into Hostinger and run:
   ```bash
   cd /home/u133241207/domains/ogexports.co/public_html/laravel_api
   bash storage/app/deploy-quotation-contact-on-prod.sh
   ```
   The script also finds the bundle if it is already under `storage/app/`.

## No-SSH File Manager deploy (drop-in)

1. Re-upload the refreshed `storage/app/quotation-contact-deploy.b64.json` into `laravel_api/storage/app/` (overwrite).
2. Upload `storage/app/apply_quote_deploy.php` to **`laravel_api/public/apply_quote_deploy.php`** (must be under `public/`, not `storage/`).
3. Open (replace token with production `MAINT_TOKEN`):
   ```text
   https://api.ogexports.co/apply_quote_deploy.php?token=YOUR_MAINT_TOKEN
   ```
4. Expect JSON `"ok": true` and a list of written files. The drop-in deletes itself after success.
5. Retest quote submit on the site.

Production server steps already verified remotely: migrations up to date, SMTP probe to `sales@ogexports.co` OK. Live `POST /api/contact` still returns **500** until the PHP files above are deployed.

## Backend — api.ogexports.co

Upload the full Laravel app, or at minimum:

- `routes/api.php`
- `app/Http/Controllers/Api/Public/ContactController.php`
- `app/Mail/ContactFormAlert.php`
- `app/Services/ContactFormMailer.php`
- `app/Models/ContactMessage.php`
- `app/Support/NotifiesAdmins.php`
- `app/Support/NotifiesUsers.php`
- `config/mail.php`
- `database/migrations/2026_07_18_010200_create_cms_tables.php` (if `contact_messages` never existed)
- `database/migrations/2026_07_27_040000_add_type_meta_to_contact_messages.php`
- `app/Http/Controllers/Api/Admin/PublicQuotationController.php` (optional, admin list)

On the server (SSH or Hostinger terminal):

```bash
cd /path/to/api
composer install --no-dev --optimize-autoloader
php artisan migrate --force
php artisan optimize:clear
```

Production `.env` (add if missing):

```env
MAIL_QUOTE_TO=sales@ogexports.co
MAIL_CONTACT_TO=info@ogexports.co
```

Ensure SMTP is configured (`MAIL_MAILER`, `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM_ADDRESS`).

Smoke test mail (replace token with `MAINT_TOKEN` from `.env`):

```text
GET https://api.ogexports.co/api/maint/mail-probe?token=YOUR_MAINT_TOKEN
```

Test quotation submit (expect **201** and `"mail_sent": true`, or **202** if SMTP fails but row is saved):

```bash
curl -X POST https://api.ogexports.co/api/contact \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d "{\"name\":\"Test\",\"email\":\"test@example.com\",\"subject\":\"Quote Request: Yellow Maize (Corn)\",\"message\":\"Company: Test\\nCountry: UK\\nQuantity: 1\\nDelivery: CIF\\n\\nTest\",\"type\":\"public_quote\",\"meta\":{\"product_id\":3,\"product_name\":\"Yellow Maize (Corn)\"}}"
```

## Frontend — ogexports.co

Source changed:

- `frontend/src/components/RequestQuoteDialog.tsx`

Production build output (upload to the site static root):

- `frontend/build/` (entire folder — includes `index.html` and `assets/`)

Build locally:

```bash
cd frontend
npm run build
```

Then upload `frontend/build/` to Hostinger (same location as current SPA).

## Verify in browser

1. https://ogexports.co/products — **Request Quote** on any product
2. https://ogexports.co/products/yellow-corn — **Request Quotation** modal

Success toast should mention **sales@ogexports.co**. Network tab: `POST https://api.ogexports.co/api/contact` → 201 (or 202 if mail down).
