<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

$sendBootstrapError = static function (string $message, int $status = 500): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowed = [
        'https://ogexports.co',
        'https://www.ogexports.co',
        'http://localhost:5000',
        'http://127.0.0.1:5000',
        'http://localhost:5003',
        'http://127.0.0.1:5003',
        'http://localhost:5173',
        'http://127.0.0.1:5173',
        'http://localhost:5055',
        'http://127.0.0.1:5055',
    ];

    if ($origin !== '' && in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: '.$origin);
        header('Access-Control-Allow-Credentials: true');
        header('Vary: Origin');
    }

    header('Content-Type: application/json; charset=UTF-8');
    http_response_code($status);

    echo json_encode([
        'message' => $message,
        'status' => $status,
    ], JSON_UNESCAPED_SLASHES);
    exit;
};

try {
    if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
        require $maintenance;
    }

    $autoload = __DIR__.'/../vendor/autoload.php';
    if (! is_file($autoload)) {
        $sendBootstrapError(
            'Composer dependencies missing. Run `composer install --no-dev --optimize-autoloader` on the API host.',
            500
        );
    }

    require $autoload;

    /** @var Application $app */
    $app = require_once __DIR__.'/../bootstrap/app.php';

    $app->handleRequest(Request::capture());
} catch (Throwable $e) {
    $detail = (($_ENV['APP_DEBUG'] ?? getenv('APP_DEBUG') ?: 'false') === 'true')
        ? $e->getMessage()
        : 'Application bootstrap failed. Check storage/logs/laravel.log and Hostinger PHP error log.';

    $sendBootstrapError($detail, 500);
}
