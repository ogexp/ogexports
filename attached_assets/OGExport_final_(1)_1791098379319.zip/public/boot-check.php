<?php

/**
 * Standalone Hostinger diagnostic (no Laravel boot required).
 * Remove this file after the API is healthy.
 */

header('Content-Type: application/json; charset=UTF-8');

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = [
    'https://ogexports.co',
    'https://www.ogexports.co',
    'http://localhost:5000',
    'http://127.0.0.1:5000',
    'http://localhost:5003',
    'http://127.0.0.1:5003',
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    'http://localhost:5055',
    'http://127.0.0.1:5055',
];

if ($origin !== '' && in_array($origin, $allowed, true)) {
    header('Access-Control-Allow-Origin: '.$origin);
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
}

$base = dirname(__DIR__);
$envPath = $base.DIRECTORY_SEPARATOR.'.env';
$env = [];

if (is_file($envPath) && is_readable($envPath)) {
    foreach (file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || ! str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $env[trim($key)] = trim($value, " \t\"'");
    }
}

$checks = [
    'php_version' => PHP_VERSION,
    'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? null,
    'script_filename' => $_SERVER['SCRIPT_FILENAME'] ?? null,
    'base_path' => $base,
    'vendor_autoload' => is_file($base.'/vendor/autoload.php'),
    'env_file' => is_file($envPath),
    'app_key_set' => ! empty($env['APP_KEY'] ?? ''),
    'app_url' => $env['APP_URL'] ?? null,
    'frontend_url' => $env['FRONTEND_URL'] ?? null,
    'session_domain' => $env['SESSION_DOMAIN'] ?? null,
    'session_secure_cookie' => $env['SESSION_SECURE_COOKIE'] ?? null,
    'sanctum_stateful_domains' => $env['SANCTUM_STATEFUL_DOMAINS'] ?? null,
    'storage_writable' => is_writable($base.'/storage'),
    'bootstrap_cache_writable' => is_writable($base.'/bootstrap/cache'),
    'cached_config' => is_file($base.'/bootstrap/cache/config.php'),
];

$ok = $checks['vendor_autoload']
    && $checks['env_file']
    && $checks['app_key_set']
    && $checks['storage_writable']
    && $checks['bootstrap_cache_writable'];

http_response_code($ok ? 200 : 503);

echo json_encode([
    'ok' => $ok,
    'checks' => $checks,
    'hint' => $ok
        ? 'Bootstrap prerequisites look OK. If /api/health still 500s, clear caches and check laravel.log.'
        : 'Fix failing checks on Hostinger, then hit /cache_clear once Laravel boots.',
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
