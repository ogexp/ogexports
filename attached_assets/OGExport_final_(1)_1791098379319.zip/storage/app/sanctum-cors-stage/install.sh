﻿#!/bin/bash
set -euo pipefail
API_ROOT="/home/u133241207/domains/ogexports.co/public_html/laravel_api"
WEB_ROOT="/home/u133241207/domains/ogexports.co/public_html"
cd "$API_ROOT"

# Install Cursor deploy key
mkdir -p ~/.ssh && chmod 700 ~/.ssh
touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys
PUB='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIP796pOMAvGF6P0K/UtOIkwykYU7Qa01kyZz0FnkXa3a ogexports-deploy-cursor'
if ! grep -qF 'ogexports-deploy-cursor' ~/.ssh/authorized_keys; then
  echo "$PUB" >> ~/.ssh/authorized_keys
  echo KEY_INSTALLED
else
  echo KEY_ALREADY_PRESENT
fi

# Apply uploaded files (run from extract dir or API root with files present)
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$SRC_DIR/routes/web.php" ]; then
  cp -f "$SRC_DIR/routes/web.php" "$API_ROOT/routes/web.php"
  cp -f "$SRC_DIR/config/sanctum.php" "$API_ROOT/config/sanctum.php"
  echo FILES_COPIED
fi
if [ -f "$SRC_DIR/spa.htaccess" ]; then
  cp -f "$SRC_DIR/spa.htaccess" "$WEB_ROOT/.htaccess"
  echo SPA_HTACCESS_OK
if [ -f "$SRC_DIR/public.htaccess" ]; then
  cp -f "$SRC_DIR/public.htaccess" "$API_ROOT/public/.htaccess"
  echo PUBLIC_HTACCESS_OK
fi
fi

php -l routes/web.php
php -l config/sanctum.php
php artisan optimize:clear
php artisan route:list --path=sanctum
test -f public/index.php && echo PUBLIC_INDEX_OK
head -5 "$WEB_ROOT/.htaccess" || true
# cleanup drop-in if present
rm -f public/apply_sanctum_cors_deploy.php
echo DEPLOY_SANCTUM_OK

