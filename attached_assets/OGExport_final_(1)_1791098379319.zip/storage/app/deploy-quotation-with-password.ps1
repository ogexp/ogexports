# Run in PowerShell on your PC (you will be prompted for Hostinger SSH password once).
# Applies the quotation-contact fix on production.

$ErrorActionPreference = "Stop"
$Port = 65002
$HostName = "145.79.30.73"
$User = "u133241207"
$ApiRoot = "/home/u133241207/domains/ogexports.co/public_html/laravel_api"
$LocalRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
if (-not (Test-Path (Join-Path $LocalRoot "artisan"))) {
  $LocalRoot = "d:\laragon\www\OGExport_final"
}

$secure = Read-Host "Hostinger SSH password for ${User}@${HostName}" -AsSecureString
$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)

# Prefer plink if available; otherwise require sshpass-like via expect not available —
# use temporary key install: upload files via scp with plink/pscp.

$pscp = Get-Command pscp -ErrorAction SilentlyContinue
$plink = Get-Command plink -ErrorAction SilentlyContinue

if (-not $pscp -or -not $plink) {
  Write-Host "PuTTY pscp/plink not found. Installing OpenSSH is not enough for non-interactive password."
  Write-Host "Falling back: will open interactive SSH. Paste this after login:"
  Write-Host ""
  Write-Host "  cd $ApiRoot && bash storage/app/deploy-quotation-contact-on-prod.sh && php artisan optimize:clear"
  Write-Host ""
  ssh -p $Port "${User}@${HostName}"
  exit 0
}

$bundle = Join-Path $LocalRoot "storage\app\quotation-contact-deploy.b64.json"
$script = Join-Path $LocalRoot "storage\app\deploy-quotation-contact-on-prod.sh"
$dropin = Join-Path $LocalRoot "storage\app\apply_quote_deploy.php"

& pscp -P $Port -pw $Password $bundle "${User}@${HostName}:${ApiRoot}/storage/app/quotation-contact-deploy.b64.json"
& pscp -P $Port -pw $Password $script "${User}@${HostName}:${ApiRoot}/storage/app/deploy-quotation-contact-on-prod.sh"
& pscp -P $Port -pw $Password $dropin "${User}@${HostName}:${ApiRoot}/public/apply_quote_deploy.php"

& plink -ssh -P $Port -pw $Password "${User}@${HostName}" "cd $ApiRoot && bash storage/app/deploy-quotation-contact-on-prod.sh && php artisan optimize:clear && echo DONE"

Write-Host "Deploy finished. Retesting API..."
curl.exe -s -w "`nHTTP:%{http_code}`n" -X POST "https://api.ogexports.co/api/contact" -H "Content-Type: application/json" -H "Accept: application/json" --data-binary "@$LocalRoot\storage\app\contact-live-test-payload.json"
