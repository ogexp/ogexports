# Non-interactive Hostinger deploy using PuTTY plink/pscp.
# Set password once in this PowerShell session:
#   $env:HOSTINGER_SSH_PASSWORD = 'your-password'
# Then:
#   powershell -ExecutionPolicy Bypass -File storage/app/deploy-quotation-plink.ps1

$ErrorActionPreference = "Stop"
$PuTTY = "C:\Program Files\PuTTY"
$pscp = Join-Path $PuTTY "pscp.exe"
$plink = Join-Path $PuTTY "plink.exe"
$Port = 65002
$HostName = "145.79.30.73"
$User = "u133241207"
$ApiRoot = "/home/u133241207/domains/ogexports.co/public_html/laravel_api"
$LocalRoot = "d:\laragon\www\OGExport_final"

$Password = $env:HOSTINGER_SSH_PASSWORD
$pwFile = Join-Path $LocalRoot "storage\app\.hostinger_ssh_password"
if (-not $Password -and (Test-Path $pwFile)) {
  $Password = (Get-Content $pwFile -Raw).Trim()
}
if (-not $Password) {
  Write-Error "Set HOSTINGER_SSH_PASSWORD or create storage/app/.hostinger_ssh_password"
}

# Accept host key automatically for this deploy
echo y | & $plink -ssh -P $Port -pw $Password "$User@$HostName" "exit" 2>$null | Out-Null

$bundle = Join-Path $LocalRoot "storage\app\quotation-contact-deploy.b64.json"
$script = Join-Path $LocalRoot "storage\app\deploy-quotation-contact-on-prod.sh"
$dropin = Join-Path $LocalRoot "storage\app\apply_quote_deploy.php"

& $pscp -P $Port -pw $Password -batch $bundle "${User}@${HostName}:${ApiRoot}/storage/app/quotation-contact-deploy.b64.json"
if ($LASTEXITCODE -ne 0) { throw "pscp bundle failed: $LASTEXITCODE" }
& $pscp -P $Port -pw $Password -batch $script "${User}@${HostName}:${ApiRoot}/storage/app/deploy-quotation-contact-on-prod.sh"
if ($LASTEXITCODE -ne 0) { throw "pscp script failed: $LASTEXITCODE" }
& $pscp -P $Port -pw $Password -batch $dropin "${User}@${HostName}:${ApiRoot}/public/apply_quote_deploy.php"
if ($LASTEXITCODE -ne 0) { throw "pscp dropin failed: $LASTEXITCODE" }

& $plink -ssh -P $Port -pw $Password -batch "$User@$HostName" "cd $ApiRoot && bash storage/app/deploy-quotation-contact-on-prod.sh && php artisan optimize:clear && echo DEPLOY_OK"
if ($LASTEXITCODE -ne 0) { throw "plink deploy failed: $LASTEXITCODE" }

Write-Host "Retesting contact API..."
& curl.exe -s -w "`nHTTP:%{http_code}`n" -X POST "https://api.ogexports.co/api/contact" -H "Content-Type: application/json" -H "Accept: application/json" --data-binary "@$LocalRoot\storage\app\contact-live-test-payload.json"
