<?php

namespace App\Http\Controllers\Api\Public;

use App\Http\Controllers\Controller;
use App\Models\ContactMessage;
use App\Models\NewsletterSubscriber;
use App\Models\PartnerApplication;
use App\Services\ContactFormMailer;
use App\Support\AdminNotificationTypes;
use App\Support\NotifiesAdmins;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function storeContact(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'subject' => ['nullable', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:5000'],
            'type' => ['nullable', 'string', 'in:contact,public_quote'],
            'meta' => ['nullable', 'array'],
            'meta.product_id' => ['nullable', 'integer'],
            'meta.product_name' => ['nullable', 'string', 'max:255'],
            'meta.company' => ['nullable', 'string', 'max:255'],
            'meta.country' => ['nullable', 'string', 'max:100'],
            'meta.quantity' => ['nullable', 'string', 'max:100'],
            'meta.delivery_term' => ['nullable', 'string', 'max:50'],
            'meta.inquiry_type' => ['nullable', 'string', 'max:100'],
            'meta.source' => ['nullable', 'string', 'max:100'],
        ]);

        $type = $data['type'] ?? 'contact';
        if (($data['subject'] ?? '') && str_starts_with((string) $data['subject'], 'Quote Request:')) {
            $type = 'public_quote';
        }

        try {
            $message = ContactMessage::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'phone' => $data['phone'] ?? null,
                'subject' => $data['subject'] ?? null,
                'message' => $data['message'],
                'status' => 'new',
                'type' => $type,
                'meta' => $data['meta'] ?? null,
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'message' => 'Unable to save your quotation request. Please try again or email sales@ogexports.co.',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 500);
        }

        $adminHref = $type === 'public_quote'
            ? '/admin/quotations'
            : '/admin/messages';

        try {
            NotifiesAdmins::notify(
                AdminNotificationTypes::CONTACT_SUBMITTED,
                'New website inquiry from '.$message->name,
                $message->subject ?: 'Contact form submission',
                [
                    'href' => $adminHref,
                    'contact_message_id' => $message->id,
                    'type' => $type,
                ]
            );
        } catch (\Throwable $e) {
            report($e);
        }

        $mailSent = ContactFormMailer::send($message);

        if (! $mailSent) {
            return response()->json([
                'message' => 'Your message was saved but email delivery failed. Our team will follow up shortly.',
                'data' => $message,
                'mail_sent' => false,
            ], 202);
        }

        return response()->json([
            'message' => 'Message sent successfully.',
            'data' => $message,
            'mail_sent' => true,
        ], 201);
    }

    public function storeNewsletter(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email', 'max:255'],
        ]);

        $subscriber = NewsletterSubscriber::query()->firstOrCreate(
            ['email' => $data['email']],
            ['subscribed_at' => now()]
        );

        if ($subscriber->unsubscribed_at) {
            $subscriber->update([
                'unsubscribed_at' => null,
                'subscribed_at' => now(),
            ]);
        }

        return response()->json([
            'message' => 'Subscribed successfully.',
            'data' => $subscriber,
        ], 201);
    }

    public function storePartner(Request $request): JsonResponse
    {
        $data = $request->validate([
            'company' => ['required', 'string', 'max:255'],
            'contact_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'type' => ['nullable', 'string', 'max:100'],
            'payload' => ['nullable', 'array'],
        ]);

        $application = PartnerApplication::create([
            ...$data,
            'status' => 'pending',
        ]);

        return response()->json([
            'message' => 'Application submitted successfully.',
            'data' => $application,
        ], 201);
    }
}
