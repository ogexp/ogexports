<?php

namespace App\Services;

use App\Mail\ContactFormAlert;
use App\Models\ContactMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class ContactFormMailer
{
    public static function send(ContactMessage $message): bool
    {
        $to = self::recipientFor($message);

        try {
            Mail::to($to)->send(new ContactFormAlert($message));

            Log::info('contact_form.mail_sent', [
                'contact_message_id' => $message->id,
                'type' => $message->type,
                'to' => $to,
                'from_email' => $message->email,
            ]);

            return true;
        } catch (\Throwable $e) {
            report($e);

            Log::error('contact_form.mail_failed', [
                'contact_message_id' => $message->id,
                'type' => $message->type,
                'to' => $to,
                'from_email' => $message->email,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    public static function recipientFor(ContactMessage $message): string
    {
        if ($message->type === 'public_quote') {
            return (string) config('mail.quote_to', 'sales@ogexports.co');
        }

        return (string) config('mail.contact_to', 'info@ogexports.co');
    }
}
