<?php

$root = dirname(__DIR__, 2);
$files = [
    'app/Services/ContactFormMailer.php',
    'app/Mail/ContactFormAlert.php',
    'app/Support/NotifiesAdmins.php',
    'app/Support/NotifiesUsers.php',
    'app/Models/ContactMessage.php',
    'app/Http/Controllers/Api/Public/ContactController.php',
    'app/Http/Controllers/Api/MaintController.php',
    'routes/api.php',
    'config/mail.php',
];

$data = [];
foreach ($files as $relative) {
    $path = $root.'/'.$relative;
    if (! is_file($path)) {
        fwrite(STDERR, "Missing: {$path}\n");
        exit(1);
    }
    $data[$relative] = base64_encode(file_get_contents($path));
}

$jsonPath = $root.'/storage/app/quotation-contact-deploy.b64.json';
file_put_contents($jsonPath, json_encode($data, JSON_PRETTY_PRINT));
echo "Wrote {$jsonPath}\n";
