# Interactive Hostinger deploy for Sanctum CSRF CORS fix.
# Opens a visible window so you can type the SSH password.
$ErrorActionPreference = 'Stop'
$PuTTY = 'C:\Program Files\PuTTY'
$pscp = Join-Path $PuTTY 'pscp.exe'
$plink = Join-Path $PuTTY 'plink.exe'
$Port = 65002
$HostName = '145.79.30.73'
$User = 'u133241207'
$ApiRoot = '/home/u133241207/domains/ogexports.co/public_html/laravel_api'
$WebRoot = '/home/u133241207/domains/ogexports.co/public_html'
$LocalRoot = 'd:\laragon\www\OGExport_final'

Write-Host '=== OGExport Sanctum CORS deploy ===' -ForegroundColor Cyan
Write-Host "Target: ${User}@${HostName}:${Port}"
$secure = Read-Host 'Hostinger SSH password' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $Password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
if ([string]::IsNullOrWhiteSpace($Password)) { throw 'Empty password' }

echo y | & $plink -ssh -P $Port -pw $Password "$User@$HostName" 'exit' 2>$null | Out-Null

$pub = (Get-Content "$env:USERPROFILE\.ssh\ogexports_deploy.pub" -Raw).Trim()
Write-Host 'Installing deploy key...'
& $plink -ssh -P $Port -pw $Password -batch "$User@$HostName" "mkdir -p ~/.ssh && chmod 700 ~/.ssh && touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys && (grep -qF 'ogexports-deploy-cursor' ~/.ssh/authorized_keys || echo '$pub' >> ~/.ssh/authorized_keys) && echo KEY_OK"
if ($LASTEXITCODE -ne 0) { throw "key install failed: $LASTEXITCODE" }

Write-Host 'Uploading routes/web.php + config/sanctum.php...'
& $pscp -P $Port -pw $Password -batch "$LocalRoot\routes\web.php" "${User}@${HostName}:${ApiRoot}/routes/web.php"
if ($LASTEXITCODE -ne 0) { throw "pscp web.php failed" }
& $pscp -P $Port -pw $Password -batch "$LocalRoot\config\sanctum.php" "${User}@${HostName}:${ApiRoot}/config/sanctum.php"
if ($LASTEXITCODE -ne 0) { throw "pscp sanctum.php failed" }

Write-Host 'Uploading SPA .htaccess (CORS strip)...'
& $pscp -P $Port -pw $Password -batch "$LocalRoot\frontend\build\.htaccess" "${User}@${HostName}:${WebRoot}/.htaccess"
if ($LASTEXITCODE -ne 0) { throw "pscp htaccess failed" }

Write-Host 'Uploading frontend build...'
& $pscp -P $Port -pw $Password -batch -r "$LocalRoot\frontend\build\*" "${User}@${HostName}:${WebRoot}/"
if ($LASTEXITCODE -ne 0) { throw "pscp frontend failed" }

Write-Host 'Clearing caches + verifying...'
& $plink -ssh -P $Port -pw $Password -batch "$User@$HostName" "cd $ApiRoot && php -l routes/web.php && php -l config/sanctum.php && php artisan optimize:clear && php artisan route:list --path=sanctum && test -f public/index.php && echo PUBLIC_INDEX_OK && head -5 .htaccess && echo DEPLOY_SANCTUM_OK"
if ($LASTEXITCODE -ne 0) { throw "verify failed: $LASTEXITCODE" }

# Save password for this machine's non-interactive deploys (gitignored)
$pwFile = Join-Path $LocalRoot 'storage\app\.hostinger_ssh_password'
Set-Content -Path $pwFile -Value $Password -NoNewline
Write-Host "Saved password to $pwFile (gitignored)" -ForegroundColor DarkGray
Write-Host 'ALL_DEPLOY_DONE' -ForegroundColor Green
Pause
