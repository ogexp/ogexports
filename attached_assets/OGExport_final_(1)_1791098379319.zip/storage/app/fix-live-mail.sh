#!/bin/bash
# Fix live OTP email on Hostinger.
# Paste into SSH after deploying MaintController + routes.
# From: /home/u133241207/domains/ogexports.co/public_html/laravel_api

set -e
cd /home/u133241207/domains/ogexports.co/public_html/laravel_api

echo "=== 1) Check MAIL_PASSWORD quoting (must include #) ==="
# If .env has MAIL_PASSWORD=Test@#6260 WITHOUT quotes, PHP only gets Test@
php -r '
require "vendor/autoload.php";
$app = require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$len = strlen((string) config("mail.mailers.smtp.password"));
echo "password_length={$len}\n";
echo "mailer=".config("mail.default")."\n";
echo "host=".config("mail.mailers.smtp.host")."\n";
echo "port=".config("mail.mailers.smtp.port")."\n";
echo "scheme=".config("mail.mailers.smtp.scheme")."\n";
echo "from=".config("mail.from.address")."\n";
if ($len < 8) {
  echo "WARNING: password looks truncated. Edit .env:\n";
  echo "  MAIL_PASSWORD=\"YourFullPasswordHere\"\n";
  echo "Then: php artisan config:clear\n";
}
'

echo "=== 2) Clear config cache ==="
php artisan optimize:clear

echo "=== 3) Seed email templates ==="
php artisan db:seed --class=EmailTemplateSeeder --force

echo "=== 4) Confirm registration_otp exists ==="
php -r '
require "vendor/autoload.php";
$app = require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$ok = App\Models\EmailTemplate::where("slug","registration_otp")->where("is_active",1)->exists();
echo $ok ? "registration_otp=OK\n" : "registration_otp=MISSING\n";
exit($ok ? 0 : 2);
'

echo "=== 5) SMTP probe to cubixmudassar@gmail.com ==="
php -r '
require "vendor/autoload.php";
$app = require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$to = "cubixmudassar@gmail.com";
try {
  Illuminate\Support\Facades\Mail::raw("Live SMTP probe ".date("c"), function ($m) use ($to) {
    $m->to($to)->subject("OGExport live SMTP probe");
  });
  echo "SEND_OK to {$to}\n";
} catch (Throwable $e) {
  echo "SEND_FAIL: ".$e->getMessage()."\n";
  exit(1);
}
'

echo "DONE"
