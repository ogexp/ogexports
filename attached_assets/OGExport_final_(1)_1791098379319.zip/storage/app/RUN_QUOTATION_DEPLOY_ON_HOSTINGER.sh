#!/bin/bash
# Paste this entire block into Hostinger SSH / Browser Terminal (one paste).
set -euo pipefail
cd /home/u133241207/domains/ogexports.co/public_html/laravel_api

# Prefer storage/app bundle (File Manager upload location)
if [ -f storage/app/deploy-quotation-contact-on-prod.sh ]; then
  bash storage/app/deploy-quotation-contact-on-prod.sh
elif [ -f deploy-quotation-contact-on-prod.sh ]; then
  bash deploy-quotation-contact-on-prod.sh
else
  echo "ERROR: deploy-quotation-contact-on-prod.sh not found under storage/app/"
  ls -la storage/app/ | head -50
  exit 1
fi

php artisan optimize:clear
echo "VERIFY:"
curl -s -o /tmp/contact_out.json -w "HTTP:%{http_code}\n" -X POST https://api.ogexports.co/api/contact \
  -H "Content-Type: application/json" -H "Accept: application/json" \
  -d '{"name":"LiveTest","email":"livetest@example.com","subject":"Quote Request: Yellow Maize (Corn)","message":"Company: Test\nCountry: UK\nQuantity: 1\nDelivery: CIF\n\nLive check","type":"public_quote","meta":{"product_id":3,"product_name":"Yellow Maize (Corn)"}}'
head -c 400 /tmp/contact_out.json; echo
