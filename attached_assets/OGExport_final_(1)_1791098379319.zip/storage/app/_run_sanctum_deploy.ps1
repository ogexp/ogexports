﻿$ErrorActionPreference = 'Stop'
try {
  & 'd:\laragon\www\OGExport_final\storage\app\deploy-sanctum-cors-interactive.ps1'
  if ($LASTEXITCODE -eq 0 -or $true) { Set-Content -Path 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value 'ok' }
} catch {
  Set-Content -Path 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value ($_.Exception.Message)
  Write-Host $_ -ForegroundColor Red
  Pause
}
