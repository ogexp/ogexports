Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'OGExport Hostinger SSH'
$form.Size = New-Object System.Drawing.Size(420,160)
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = 'Enter Hostinger SSH password to finish Sanctum CORS deploy:'
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(12,12)
$form.Controls.Add($label)

$box = New-Object System.Windows.Forms.TextBox
$box.UseSystemPasswordChar = $true
$box.Width = 370
$box.Location = New-Object System.Drawing.Point(12,40)
$form.Controls.Add($box)

$ok = New-Object System.Windows.Forms.Button
$ok.Text = 'Deploy'
$ok.Location = New-Object System.Drawing.Point(220,75)
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $ok
$form.Controls.Add($ok)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = 'Cancel'
$cancel.Location = New-Object System.Drawing.Point(305,75)
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancel
$form.Controls.Add($cancel)

$result = $form.ShowDialog()
if ($result -ne [System.Windows.Forms.DialogResult]::OK -or [string]::IsNullOrWhiteSpace($box.Text)) {
  Set-Content 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value 'cancelled'
  exit 1
}

$pwFile = 'd:\laragon\www\OGExport_final\storage\app\.hostinger_ssh_password'
Set-Content -Path $pwFile -Value $box.Text -NoNewline
Set-Content 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value 'password_saved'
