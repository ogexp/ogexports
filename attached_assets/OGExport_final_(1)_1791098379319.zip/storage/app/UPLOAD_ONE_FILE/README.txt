# Fix live Request Quotation (ONE file)

## Why the frontend shows 500

- Product pages call **https://api.ogexports.co/api/contact** (Laravel API on Hostinger).
- The React form is fine. The **API PHP on the server** is crashing after validation.
- Changing code only on your PC does not change api.ogexports.co until you overwrite that one controller on Hostinger.

## Fix (File Manager — 60 seconds)

1. Open Hostinger File Manager →  
   `domains/ogexports.co/public_html/laravel_api/app/Http/Controllers/Api/Public/`
2. Replace **`ContactController.php`** with:  
   `storage/app/UPLOAD_ONE_FILE/ContactController.php` (from this project)
3. (Optional) In SSH or File Manager terminal on `laravel_api`:  
   `php artisan optimize:clear`
4. Submit Request Quote again — expect success toast, not 500.

That single file: validates → saves `contact_messages` → emails `sales@ogexports.co` (quotes) / `info@ogexports.co` (contact) → returns JSON. Admin notify is optional and cannot crash the request.
