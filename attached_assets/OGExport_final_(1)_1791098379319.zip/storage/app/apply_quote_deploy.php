<?php
/**
 * One-shot production deploy helper for quotation contact fix.
 * Upload THIS file to: laravel_api/public/apply_quote_deploy.php
 * Ensure storage/app/quotation-contact-deploy.b64.json already exists.
 * Then open:
 *   https://api.ogexports.co/apply_quote_deploy.php?token=YOUR_MAINT_TOKEN
 * The script deletes itself after a successful apply.
 */

declare(strict_types=1);

header('Content-Type: application/json');

$token = (string) ($_GET['token'] ?? '');
$expected = '';

// Load MAINT_TOKEN from ../.env without bootstrapping Laravel.
$envPath = dirname(__DIR__).'/.env';
if (is_file($envPath)) {
    foreach (file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || ! str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        if (trim($key) === 'MAINT_TOKEN') {
            $expected = trim($value, " \t\"'");
            break;
        }
    }
}

if ($expected === '' || ! hash_equals($expected, $token)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid maintenance token.']);
    exit;
}

$root = dirname(__DIR__);
$candidates = [
    $root.'/storage/app/quotation-contact-deploy.b64.json',
    $root.'/quotation-contact-deploy.b64.json',
];

$bundlePath = null;
foreach ($candidates as $path) {
    if (is_file($path)) {
        $bundlePath = $path;
        break;
    }
}

if ($bundlePath === null) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Bundle missing under storage/app/.']);
    exit;
}

$json = json_decode((string) file_get_contents($bundlePath), true);
if (! is_array($json)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Invalid bundle JSON.']);
    exit;
}

$wrote = [];
foreach ($json as $relative => $b64) {
    if (! is_string($relative) || ! is_string($b64)) {
        continue;
    }
    if (! str_starts_with($relative, 'app/') && $relative !== 'routes/api.php' && $relative !== 'config/mail.php') {
        continue;
    }
    $target = $root.'/'.$relative;
    $dir = dirname($target);
    if (! is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    if (is_file($target)) {
        copy($target, $target.'.bak-quotation-'.date('YmdHis'));
    }
    $decoded = base64_decode($b64, true);
    if ($decoded === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => "Invalid base64 for {$relative}"]);
        exit;
    }
    file_put_contents($target, $decoded);
    $wrote[] = $relative;
}

// Clear common caches if artisan is available.
$artisanOut = null;
$artisan = $root.'/artisan';
if (is_file($artisan)) {
    $cmd = 'cd '.escapeshellarg($root).' && php artisan migrate --force && php artisan optimize:clear 2>&1';
    $artisanOut = shell_exec($cmd);
}

@unlink(__FILE__);

echo json_encode([
    'ok' => true,
    'bundle' => $bundlePath,
    'wrote' => $wrote,
    'artisan' => $artisanOut,
    'self_deleted' => ! is_file(__FILE__),
], JSON_PRETTY_PRINT);
