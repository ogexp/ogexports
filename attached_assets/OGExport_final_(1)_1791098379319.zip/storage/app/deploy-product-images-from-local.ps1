# Upload product catalog images to Hostinger production API server.
# Run interactively in PowerShell (you will be prompted for SSH password).
#
# Prerequisites: OpenSSH client (scp) available on Windows.

$ErrorActionPreference = "Stop"

$LocalDir = Join-Path $PSScriptRoot "..\..\public\product_images"
$Remote = "u133241207@145.79.30.73:/home/u133241207/domains/ogexports.co/public_html/laravel_api/public/product_images/"
$Port = 65002

if (-not (Test-Path $LocalDir)) {
    Write-Error "Missing folder: $LocalDir"
}

# Ensure production DB filenames exist (map from local primary images)
$maps = @{
    "sesame-seeds-1786444604-0-4selij.png" = "sesame-seeds-primary-cff6e9ebb17f.png"
    "yellow-maize-corn-1786446499-0-ejb2oz.png" = "yellow-corn-primary-ac63c5239bd3.png"
}
foreach ($dest in $maps.Keys) {
    $source = Join-Path $LocalDir $maps[$dest]
    $target = Join-Path $LocalDir $dest
    if (Test-Path $source) {
        Copy-Item $source $target -Force
        Write-Host "Prepared $dest from $($maps[$dest])"
    }
}

Write-Host "Uploading product images to production..."
Write-Host "Remote: $Remote"
scp -P $Port -r (Join-Path $LocalDir "*") $Remote

Write-Host ""
Write-Host "Setting permissions on server (SSH)..."
ssh -p $Port u133241207@145.79.30.73 "chmod -R 755 /home/u133241207/domains/ogexports.co/public_html/laravel_api/public/product_images"

Write-Host ""
Write-Host "Verifying sample image..."
curl.exe -sI "https://api.ogexports.co/product_images/sesame-seeds-1786444604-0-4selij.png" | Select-Object -First 3
Write-Host "Done. Hard-refresh https://ogexports.co/"
