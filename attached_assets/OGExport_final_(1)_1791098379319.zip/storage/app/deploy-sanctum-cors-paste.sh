#!/bin/bash
# Paste into the open Hostinger SSH session (laravel_api cwd).
set -euo pipefail
API_ROOT="/home/u133241207/domains/ogexports.co/public_html/laravel_api"
WEB_ROOT="/home/u133241207/domains/ogexports.co/public_html"
cd "$API_ROOT"

# Install Cursor deploy key for future non-interactive deploys
mkdir -p ~/.ssh && chmod 700 ~/.ssh
touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys
PUB='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIP796pOMAvGF6P0K/UtOIkwykYU7Qa01kyZz0FnkXa3a ogexports-deploy-cursor'
if ! grep -qF 'ogexports-deploy-cursor' ~/.ssh/authorized_keys; then
  echo "$PUB" >> ~/.ssh/authorized_keys
  echo "KEY_INSTALLED"
else
  echo "KEY_ALREADY_PRESENT"
fi

# Patch Sanctum CSRF route (survives route:cache)
php -r '
$path = "routes/web.php";
$src = file_get_contents($path);
if ($src === false) { fwrite(STDERR, "read fail\n"); exit(1); }
if (str_contains($src, "CsrfCookieController")) {
  echo "WEB_PHP_ALREADY_PATCHED\n";
  exit(0);
}
$needle = "use Illuminate\\Support\\Facades\\Route;\n";
$insert = $needle . "use Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController;\n\n"
  . "// Explicit Sanctum CSRF route so it survives `php artisan route:cache`\n"
  . "// (SanctumServiceProvider skips route registration when routes are cached).\n"
  . "Route::get('\''/sanctum/csrf-cookie'\'', [CsrfCookieController::class, '\''show'\''])\n"
  . "    ->middleware('\''web'\'')\n"
  . "    ->name('\''sanctum.csrf-cookie'\'');\n\n";
if (!str_contains($src, $needle)) { fwrite(STDERR, "needle missing\n"); exit(1); }
$out = str_replace($needle, $insert, $src, $count);
if ($count !== 1) { fwrite(STDERR, "replace count=$count\n"); exit(1); }
file_put_contents($path, $out);
echo "WEB_PHP_PATCHED\n";
'

php -l routes/web.php
php artisan optimize:clear
php artisan route:list --path=sanctum

# Strengthen SPA .htaccess CORS strip (CDN may still inject; Apache strip helps origin)
cat > "$WEB_ROOT/.htaccess" <<'HTA'
# Strip any panel/CDN-injected CORS headers from the SPA.
# Cross-origin policy must be set only by the Laravel API (api.ogexports.co).
<IfModule mod_headers.c>
    Header always unset Access-Control-Allow-Origin
    Header always unset Access-Control-Allow-Methods
    Header always unset Access-Control-Allow-Headers
    Header always unset Access-Control-Allow-Credentials
    Header always unset Access-Control-Max-Age
    Header unset Access-Control-Allow-Origin
    Header unset Access-Control-Allow-Methods
    Header unset Access-Control-Allow-Headers
    Header unset Access-Control-Allow-Credentials
    Header unset Access-Control-Max-Age
</IfModule>

<IfModule mod_rewrite.c>
    Options -MultiViews
    RewriteEngine On
    RewriteBase /

    # Avoid /products -> /products/ 301 that shadows the SPA when a dir exists.
    DirectorySlash Off

    # Force SPA for product routes even if a static products/ folder reappears.
    RewriteRule ^products/?$ index.html [L]
    RewriteRule ^products/[^/]+/?$ index.html [L]

    # Serve existing assets and directories normally.
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d

    # Let the React router handle every application route.
    RewriteRule ^ index.html [L]
</IfModule>
HTA

# Confirm API docroot wiring
test -f public/index.php && echo PUBLIC_INDEX_OK
test -f .htaccess && echo ROOT_HTACCESS_OK
grep -n "sanctum/csrf-cookie" routes/web.php | head
echo DEPLOY_SANCTUM_OK
