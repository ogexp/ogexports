<?php

require __DIR__.'/../../vendor/autoload.php';

$app = require __DIR__.'/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$to = $argv[1] ?? 'cubixmudassar@gmail.com';

echo 'mailer='.config('mail.default').PHP_EOL;
echo 'host='.config('mail.mailers.smtp.host').PHP_EOL;
echo 'port='.config('mail.mailers.smtp.port').PHP_EOL;
echo 'scheme='.(config('mail.mailers.smtp.scheme') ?: 'null').PHP_EOL;
echo 'from='.config('mail.from.address').PHP_EOL;
echo 'username='.config('mail.mailers.smtp.username').PHP_EOL;
echo 'password_set='.(filled(config('mail.mailers.smtp.password')) ? 'yes' : 'no').PHP_EOL;

$otpOk = App\Models\EmailTemplate::query()
    ->where('slug', 'registration_otp')
    ->where('is_active', true)
    ->exists();
echo 'registration_otp_template='.($otpOk ? 'OK' : 'MISSING').PHP_EOL;

try {
    Illuminate\Support\Facades\Mail::raw(
        'OGExport SMTP probe at '.now()->toIso8601String(),
        function ($message) use ($to) {
            $message->to($to)->subject('OGExport SMTP probe');
        }
    );
    echo "SEND_OK to {$to}".PHP_EOL;
} catch (Throwable $e) {
    echo 'SEND_FAIL: '.$e->getMessage().PHP_EOL;
    exit(1);
}
