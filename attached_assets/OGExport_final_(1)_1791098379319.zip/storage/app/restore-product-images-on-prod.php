<?php

declare(strict_types=1);

/**
 * Run on production API server (no new deploy required):
 *   cd /home/u133241207/domains/ogexports.co/public_html/laravel_api
 *   php storage/app/restore-product-images-on-prod.php
 *
 * Or paste this file onto the server and run with php.
 */

chdir('/home/u133241207/domains/ogexports.co/public_html/laravel_api');

require 'vendor/autoload.php';

$app = require 'bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Product;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;

$restored = 0;
$skipped = 0;
$failed = 0;

Product::query()
    ->whereNotNull('image_url')
    ->where('image_url', '!=', '')
    ->orderBy('id')
    ->each(function (Product $product) use (&$restored, &$skipped, &$failed): void {
        $relative = ltrim((string) $product->image_url, '/');
        if (! str_starts_with($relative, 'product_images/')) {
            $skipped++;

            return;
        }

        $absolute = public_path($relative);
        if (is_file($absolute)) {
            $skipped++;

            return;
        }

        $keywords = str_replace('-', ',', (string) ($product->slug ?: 'agriculture'));
        $lock = abs(crc32($relative)) % 1000;

        try {
            $response = Http::timeout(60)->get("https://loremflickr.com/1200/800/{$keywords}?lock={$lock}");
            if (! $response->successful()) {
                echo "FAIL {$product->slug} HTTP {$response->status()}\n";
                $failed++;

                return;
            }

            File::ensureDirectoryExists(dirname($absolute));
            File::put($absolute, $response->body());
            chmod($absolute, 0644);
            echo "OK {$relative}\n";
            $restored++;
        } catch (Throwable $e) {
            echo "FAIL {$product->slug}: {$e->getMessage()}\n";
            $failed++;
        }
    });

echo "Done. restored={$restored} skipped={$skipped} failed={$failed}\n";
