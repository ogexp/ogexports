﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object System.Windows.Forms.Form
$form.Text = 'OGExport deploy - SSH password needed'
$form.Size = New-Object System.Drawing.Size(500,210)
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true
$form.FormBorderStyle = 'FixedDialog'
$label = New-Object System.Windows.Forms.Label
$label.Text = "SSH session closed. Enter Hostinger password to finish Sanctum CORS deploy."
$label.Location = New-Object System.Drawing.Point(12,16)
$label.Size = New-Object System.Drawing.Size(460,40)
$form.Controls.Add($label)
$box = New-Object System.Windows.Forms.TextBox
$box.UseSystemPasswordChar = $true
$box.Width = 460
$box.Location = New-Object System.Drawing.Point(12,70)
$form.Controls.Add($box)
$ok = New-Object System.Windows.Forms.Button
$ok.Text = 'Deploy'
$ok.Location = New-Object System.Drawing.Point(280,120)
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $ok
$form.Controls.Add($ok)
$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = 'Cancel'
$cancel.Location = New-Object System.Drawing.Point(380,120)
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)
$r = $form.ShowDialog()
if ($r -eq [System.Windows.Forms.DialogResult]::OK -and $box.Text) {
  Set-Content 'd:\laragon\www\OGExport_final\storage\app\.hostinger_ssh_password' -Value $box.Text -NoNewline
  Set-Content 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value 'password_saved'
} else {
  Set-Content 'd:\laragon\www\OGExport_final\storage\app\.sanctum_deploy_done' -Value 'cancelled'
}
