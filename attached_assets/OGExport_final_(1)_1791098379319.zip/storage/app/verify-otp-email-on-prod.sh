#!/bin/bash
# Run on Hostinger after deploying the OTP recovery logging changes.
# From: /home/u133241207/domains/ogexports.co/public_html/laravel_api

set -e
cd /home/u133241207/domains/ogexports.co/public_html/laravel_api

php artisan config:clear
php artisan optimize:clear

echo "=== registration_otp template ==="
php -r '
require "vendor/autoload.php";
$app = require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$ok = App\Models\EmailTemplate::where("slug","registration_otp")->where("is_active",1)->exists();
echo $ok ? "OK\n" : "MISSING\n";
if (!$ok) {
    exit(2);
}
'

STATUS=$?
if [ "$STATUS" -eq 2 ]; then
  echo "Seeding EmailTemplateSeeder..."
  php artisan db:seed --class=EmailTemplateSeeder --force
fi

echo "=== recent auth.email / auth.otp lines ==="
if [ -f storage/logs/laravel.log ]; then
  grep -E "auth\.(email|otp|registration|register\.resend)" storage/logs/laravel.log | tail -n 40 || true
else
  echo "No laravel.log yet"
fi

echo "DONE"
