<?php

$root = dirname(__DIR__, 2);
$json = file_get_contents($root.'/storage/app/quotation-contact-deploy.b64.json');
$script = file_get_contents($root.'/storage/app/deploy-quotation-contact-on-prod.sh');

$out = "#!/bin/bash\nset -euo pipefail\n";
$out .= "cd /home/u133241207/domains/ogexports.co/public_html/laravel_api\n";
$out .= "mkdir -p storage/app\n";
$out .= "cat > storage/app/quotation-contact-deploy.b64.json << 'ENDOFBUNDLE'\n";
$out .= $json."\n";
$out .= "ENDOFBUNDLE\n\n";
$out .= "cat > storage/app/deploy-quotation-contact-on-prod.sh << 'ENDOFSCRIPT'\n";
$out .= $script."\n";
$out .= "ENDOFSCRIPT\n";
$out .= "chmod +x storage/app/deploy-quotation-contact-on-prod.sh\n";
$out .= "bash storage/app/deploy-quotation-contact-on-prod.sh\n";

$path = $root.'/storage/app/deploy-quotation-contact-prod-paste.sh';
file_put_contents($path, $out);
echo "Wrote {$path} (".filesize($path)." bytes)\n";
