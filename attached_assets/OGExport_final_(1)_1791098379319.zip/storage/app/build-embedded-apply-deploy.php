<?php

$root = dirname(__DIR__, 2);
$json = file_get_contents($root.'/storage/app/quotation-contact-deploy.b64.json');
if ($json === false) {
    fwrite(STDERR, "Missing quotation-contact-deploy.b64.json\n");
    exit(1);
}

$out = <<<'PHP'
<?php
/**
 * One-shot embedded deploy for quotation/contact fix (mail_error + save-first).
 * Upload ONLY this file to: laravel_api/public/apply_quote_deploy.php
 * Open: https://api.ogexports.co/apply_quote_deploy.php?token=YOUR_MAINT_TOKEN
 * Self-deletes after success.
 */
declare(strict_types=1);

header('Content-Type: application/json');

$token = (string) ($_GET['token'] ?? '');
$expected = '';

$envPath = dirname(__DIR__).'/.env';
if (is_file($envPath)) {
    foreach (file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || ! str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        if (trim($key) === 'MAINT_TOKEN') {
            $expected = trim($value, " \t\"'");
            break;
        }
    }
}

if ($expected === '' || ! hash_equals($expected, $token)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Invalid maintenance token.']);
    exit;
}

$root = dirname(__DIR__);
$json = json_decode(<<<'BUNDLE'
PHP;

$out .= $json."\n";
$out .= <<<'PHP'
BUNDLE
, true);

if (! is_array($json)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Invalid embedded bundle.']);
    exit;
}

$wrote = [];
foreach ($json as $relative => $b64) {
    if (! is_string($relative) || ! is_string($b64)) {
        continue;
    }
    if (
        ! str_starts_with($relative, 'app/')
        && $relative !== 'routes/api.php'
        && $relative !== 'config/mail.php'
    ) {
        continue;
    }
    $target = $root.'/'.$relative;
    $dir = dirname($target);
    if (! is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    if (is_file($target)) {
        copy($target, $target.'.bak-quotation-'.date('YmdHis'));
    }
    $decoded = base64_decode($b64, true);
    if ($decoded === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => "Invalid base64 for {$relative}"]);
        exit;
    }
    file_put_contents($target, $decoded);
    $wrote[] = $relative;
}

$artisanOut = null;
$artisan = $root.'/artisan';
if (is_file($artisan)) {
    $cmd = 'cd '.escapeshellarg($root).' && php artisan migrate --force && php artisan optimize:clear 2>&1';
    $artisanOut = shell_exec($cmd);
}

@unlink(__FILE__);

echo json_encode([
    'ok' => true,
    'wrote' => $wrote,
    'artisan' => $artisanOut,
    'self_deleted' => ! is_file(__FILE__),
], JSON_PRETTY_PRINT);
PHP;

$path = $root.'/storage/app/apply_quote_deploy_embedded.php';
file_put_contents($path, $out);
echo "Wrote {$path} (".filesize($path)." bytes)\n";
