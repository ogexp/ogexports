#!/bin/bash
# Product catalog images live under public/product_images/ and are NOT deployed by
# git/code-only releases. Run this after adding or updating product images locally.
#
# Production Laravel API root:
#   /home/u133241207/domains/ogexports.co/public_html/laravel_api
#
# IMPORTANT: Production DB may reference filenames from admin uploads on the server
# (e.g. sesame-seeds-1786444604-0-4selij.png). Local seeded files use different
# names. Before upload, run deploy-product-images-from-local.ps1 on Windows — it
# copies primary images to production-expected filenames, then scp's the folder.
#
# From your local machine (Windows PowerShell):
#   powershell -ExecutionPolicy Bypass -File storage/app/deploy-product-images-from-local.ps1
#
# If SCP password auth is unavailable, paste on the server instead:
#   storage/app/deploy-product-images-prod-paste.sh
# (contains base64 payloads for featured product images — paste entire file into SSH)
#
# Quick fix without uploading files (uses placeholder downloads for missing paths):
#   php storage/app/restore-product-images-on-prod.php
#   scp -P 65002 -r "d:\laragon\www\OGExport_final\public\product_images\*" \
#     u133241207@145.79.30.73:/home/u133241207/domains/ogexports.co/public_html/laravel_api/public/product_images/
#
# On the server (after upload), ensure permissions:
set -e
TARGET="/home/u133241207/domains/ogexports.co/public_html/laravel_api/public/product_images"

mkdir -p "$TARGET"
chmod -R 755 "$TARGET"

if [ -f artisan ]; then
  echo "==> Restoring any missing product_images referenced in DB..."
  php artisan products:restore-missing-images || true
fi

echo "==> Product images directory:"
ls -la "$TARGET" | head -20

echo ""
echo "==> Sample URL check (replace filename if needed):"
SAMPLE="$(ls "$TARGET" 2>/dev/null | head -1)"
if [ -n "$SAMPLE" ]; then
  curl -sI "https://api.ogexports.co/product_images/$SAMPLE" | head -5
else
  echo "No files in $TARGET — upload from local public/product_images/ first."
fi

echo ""
echo "DONE — verify https://ogexports.co/ homepage product cards."
