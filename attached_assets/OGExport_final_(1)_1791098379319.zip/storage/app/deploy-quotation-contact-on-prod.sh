#!/bin/bash
# Run on Hostinger SSH after uploading quotation-contact-deploy.b64.json.
# Looks in API root and storage/app/ (where File Manager uploads often land).
# Path: /home/u133241207/domains/ogexports.co/public_html/laravel_api
set -euo pipefail

ROOT="${1:-/home/u133241207/domains/ogexports.co/public_html/laravel_api}"
cd "$ROOT"

BUNDLE=""
for candidate in \
  "quotation-contact-deploy.b64.json" \
  "storage/app/quotation-contact-deploy.b64.json"
do
  if [ -f "$candidate" ]; then
    BUNDLE="$candidate"
    break
  fi
done

if [ -z "$BUNDLE" ]; then
  echo "Upload storage/app/quotation-contact-deploy.b64.json from your dev machine to:"
  echo "  $ROOT/storage/app/quotation-contact-deploy.b64.json"
  echo "  (or $ROOT/quotation-contact-deploy.b64.json)"
  exit 1
fi

echo "Using bundle: $BUNDLE"

php -r '
$bundle = $argv[1];
$json = json_decode(file_get_contents($bundle), true);
if (! is_array($json)) {
    fwrite(STDERR, "Invalid bundle JSON\n");
    exit(1);
}
foreach ($json as $relative => $b64) {
    $dir = dirname($relative);
    if ($dir !== "." && ! is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $backup = $relative.".bak-quotation-".date("YmdHis");
    if (is_file($relative)) {
        copy($relative, $backup);
    }
    file_put_contents($relative, base64_decode($b64, true));
    echo "Wrote $relative\n";
}
' "$BUNDLE"

# Ensure quote recipient config exists
if ! grep -q "quote_to" config/mail.php 2>/dev/null; then
  echo "WARN: config/mail.php missing quote_to — upload config/mail.php from repo"
fi

php artisan migrate --force
php artisan optimize:clear

php -r "
require 'vendor/autoload.php';
\$app = require 'bootstrap/app.php';
\$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
\$cols = array_column(Illuminate\Support\Facades\DB::select('SHOW COLUMNS FROM contact_messages'), 'Field');
echo 'contact_messages columns: ' . implode(', ', \$cols) . PHP_EOL;
"

echo "DONE — retest POST /api/contact (expect 201 or 202)."
