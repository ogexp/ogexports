﻿<?php
// One-shot Sanctum CORS deploy. Delete after use.
$token = $_GET['token'] ?? '';
$envToken = '';
$envFile = dirname(__DIR__).'/.env';
if (is_file($envFile)) {
  foreach (file($envFile, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
    if (str_starts_with(trim($line), 'MAINT_TOKEN=')) {
      $envToken = trim(substr(trim($line), strlen('MAINT_TOKEN=')), " \t\"'");
      break;
    }
  }
}
if ($envToken === '' || !hash_equals($envToken, (string)$token)) {
  http_response_code(403);
  header('Content-Type: application/json');
  echo json_encode(['ok'=>false,'error'=>'forbidden']);
  exit;
}
$root = dirname(__DIR__);
$results = [];

// 1) Ensure sanctum routes=false
$sanctum = $root.'/config/sanctum.php';
$s = file_get_contents($sanctum);
if ($s !== false && !preg_match("/'routes'\s*=>\s*false/", $s)) {
  $s2 = preg_replace('/return\s*\[/', "return [\n\n    'routes' => false,", $s, 1, $c);
  if ($c === 1) { file_put_contents($sanctum, $s2); $results[] = 'sanctum_routes_false'; }
  else { $results[] = 'sanctum_patch_failed'; }
} else { $results[] = 'sanctum_ok'; }

// 2) Ensure web.php has CsrfCookieController route
$web = $root.'/routes/web.php';
$w = file_get_contents($web);
if ($w !== false && !str_contains($w, 'CsrfCookieController')) {
  $needle = "use Illuminate\\Support\\Facades\\Route;\n";
  $insert = $needle."use Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController;\n\n"
    ."Route::get('/sanctum/csrf-cookie', [CsrfCookieController::class, 'show'])\n"
    ."    ->middleware('web')\n"
    ."    ->name('sanctum.csrf-cookie');\n\n";
  if (str_contains($w, $needle)) {
    file_put_contents($web, str_replace($needle, $insert, $w));
    $results[] = 'web_patched';
  } else { $results[] = 'web_needle_missing'; }
} else { $results[] = 'web_ok'; }

// 3) SPA htaccess CORS strip
$ht = <<<'HTA'
# Strip any panel/CDN-injected CORS headers from the SPA.
<IfModule mod_headers.c>
    Header always unset Access-Control-Allow-Origin
    Header always unset Access-Control-Allow-Methods
    Header always unset Access-Control-Allow-Headers
    Header always unset Access-Control-Allow-Credentials
    Header always unset Access-Control-Max-Age
    Header unset Access-Control-Allow-Origin
    Header unset Access-Control-Allow-Methods
    Header unset Access-Control-Allow-Headers
    Header unset Access-Control-Allow-Credentials
    Header unset Access-Control-Max-Age
</IfModule>

<IfModule mod_rewrite.c>
    Options -MultiViews
    RewriteEngine On
    RewriteBase /
    DirectorySlash Off
    RewriteRule ^products/?$ index.html [L]
    RewriteRule ^products/[^/]+/?$ index.html [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^ index.html [L]
</IfModule>
HTA;
$spaHt = dirname($root).'/.htaccess'; // public_html/.htaccess when api is laravel_api
// Prefer sibling public_html when this app lives in laravel_api
$candidates = [
  dirname($root).'/.htaccess',
  $root.'/../.htaccess',
];
foreach ($candidates as $cand) {
  $real = realpath(dirname($cand)) ? (rtrim(str_replace('\\','/',dirname($cand)),'/').'/.htaccess') : $cand;
  if (is_dir(dirname($cand)) || is_dir(dirname($real))) {
    file_put_contents($cand, $ht);
    $results[] = 'spa_htaccess:'.$cand;
    break;
  }
}

// 4) Clear caches
passthru('cd '.escapeshellarg($root).' && php artisan optimize:clear 2>&1', $code);
$results[] = 'optimize_clear_exit:'.$code;

header('Content-Type: application/json');
echo json_encode(['ok'=>true,'results'=>$results], JSON_PRETTY_PRINT);
