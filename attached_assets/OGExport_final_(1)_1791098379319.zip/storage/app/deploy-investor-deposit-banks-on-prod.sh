#!/bin/bash
# Run from: /home/u133241207/domains/ogexports.co/public_html/laravel_api
# Deploys investor deposit bank-account API + migration + seeds default account.
#
# After this script, upload frontend/build/* to the ogexports.co site root
# (replace existing index.html and assets/).
#
# If new product images were added locally, also sync public/product_images/
# — see storage/app/deploy-product-images-on-prod.sh

set -e
cd /home/u133241207/domains/ogexports.co/public_html/laravel_api

echo "==> Running migration (bank_account_id on deposits)..."
php artisan migrate --force

echo "==> Seeding default bank account if missing..."
php artisan db:seed --class=BankAccountSeeder --force

echo "==> Clearing caches..."
php artisan route:clear
php artisan config:clear
php artisan cache:clear

echo "==> Verifying routes..."
php artisan route:list --path=investor/payment-bank-accounts

echo "==> Verifying bank_accounts table..."
php -r "
require 'vendor/autoload.php';
\$app = require 'bootstrap/app.php';
\$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
\$count = Illuminate\Support\Facades\DB::table('bank_accounts')->where('is_active', true)->count();
echo 'Active bank accounts: ' . \$count . PHP_EOL;
"

echo ""
echo "DONE — backend ready."
echo "Next: upload frontend/build/* from your local machine to ogexports.co public_html (site root)."
