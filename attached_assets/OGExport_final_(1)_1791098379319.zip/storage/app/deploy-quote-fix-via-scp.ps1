# Interactive Hostinger upload for quotation/contact mail_error fix + frontend build.
# You will be prompted for the SSH password.
#
# Usage (from repo root):
#   powershell -ExecutionPolicy Bypass -File storage/app/deploy-quote-fix-via-scp.ps1

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$HostUser = "u133241207@145.79.30.73"
$Port = 65002
$ApiRoot = "/home/u133241207/domains/ogexports.co/public_html/laravel_api"
$WebRoot = "/home/u133241207/domains/ogexports.co/public_html"

$Embedded = Join-Path $Root "storage\app\quotation-deploy-upload\apply_quote_deploy.php"
$FrontendBuild = Join-Path $Root "frontend\build"

if (-not (Test-Path $Embedded)) {
    Write-Error "Missing $Embedded — run: php storage/app/build-quotation-deploy-bundle.php; php storage/app/build-embedded-apply-deploy.php"
}
if (-not (Test-Path $FrontendBuild)) {
    Write-Error "Missing $FrontendBuild — run: cd frontend; npm run build"
}

Write-Host "1) Uploading embedded apply_quote_deploy.php to API public/ ..."
scp -P $Port $Embedded "${HostUser}:${ApiRoot}/public/apply_quote_deploy.php"

Write-Host ""
Write-Host "2) Open this URL in a browser (use production MAINT_TOKEN):"
Write-Host "   https://api.ogexports.co/apply_quote_deploy.php?token=YOUR_MAINT_TOKEN"
Write-Host "   Expect JSON ok:true then the script self-deletes."
Write-Host ""
$confirm = Read-Host "Press Enter after the apply URL succeeded (or type skip to continue)"

Write-Host "3) Uploading frontend/build to website root ..."
scp -P $Port -r (Join-Path $FrontendBuild "*") "${HostUser}:${WebRoot}/"

Write-Host ""
Write-Host "Done. Hard-refresh https://ogexports.co/products and retest Request Quote."
