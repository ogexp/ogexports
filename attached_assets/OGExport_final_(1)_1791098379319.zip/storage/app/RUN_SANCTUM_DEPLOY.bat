@echo off
title OGExport Sanctum CORS Deploy
cd /d d:\laragon\www\OGExport_final
echo.
echo === Option A: automatic deploy ===
echo Enter Hostinger SSH password, then press Enter.
echo.
set /p PW=SSH password: 
if "%PW%"=="" goto paste
echo %PW%>storage\app\.hostinger_ssh_password
powershell -NoProfile -ExecutionPolicy Bypass -File storage\app\deploy-sanctum-cors-from-pwfile.ps1
if errorlevel 1 (
  echo DEPLOY FAILED
  pause
  exit /b 1
)
echo.
echo SUCCESS
pause
exit /b 0

:paste
echo.
echo === Option B: paste into SSH ===
echo Reconnect SSH, then paste this single line:
echo.
type storage\app\sanctum-cors-remote-cmd.txt
echo.
pause
