<?php

/**
 * Hostinger fallback when the domain document root is the project root
 * instead of /public. Prefer pointing the domain at /public in hPanel.
 */
require __DIR__.'/public/index.php';
