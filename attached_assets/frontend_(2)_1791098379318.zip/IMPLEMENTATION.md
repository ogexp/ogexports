# OG Exports — Implementation Document

> **Purpose:** Blueprint for wiring the existing React frontend to a Laravel API-only backend.  
> **Scope:** Public site, Admin panel, Buyer / Supplier / Investor portals.  
> **Status of UI today:** Feature-rich prototype; most data is `localStorage` (`src/lib/admin-data.ts`, `src/lib/cms-data.ts`) or hardcoded mocks. `packages/api-client-react` is stubbed.  
> **Generated from:** Frontend analysis of `src/App.tsx`, portal layouts, and admin/CMS data stores.

---

## 1. Executive Summary

### Current stack (frontend)

| Layer | Technology |
|-------|------------|
| App | Vite + React 19 + TypeScript |
| Routing | Wouter (`src/App.tsx`) |
| UI | Tailwind + shadcn/Radix |
| Data fetching | TanStack Query (hooks mostly stubbed) |
| i18n | i18next (en / ur / zh) — partial coverage |
| Auth (optional) | Clerk when `VITE_CLERK_PUBLISHABLE_KEY` is set |
| Auth (default demo) | Local `localStorage` via `src/lib/local-auth.tsx` |

### Target architecture

| Surface | Tech |
|---------|------|
| Public frontend | React (existing marketing + catalog pages) |
| Admin panel | React (`/admin/*`) |
| User panels | React (`/buyer/*`, `/supplier/*`, `/invest/*`) |
| Backend | **Laravel — APIs only** (no Blade UI for these panels) |
| Auth | **Laravel Sanctum** (SPA cookie or token) |

### Roles

| Role | Self-register? | Default post-login redirect |
|------|----------------|-----------------------------|
| `admin` | No (seeded / created by super-admin) | `/admin/dashboard` |
| `buyer` | Yes | `/buyer/dashboard` |
| `supplier` | Yes | `/supplier/dashboard` |
| `investor` | Yes | `/invest/dashboard` |

### Dual portal note

The codebase has two parallel UX patterns:

1. **Dedicated role routes** (primary, recommended): `/buyer/*`, `/supplier/*`, `/invest/*`, `/admin/*`
2. **Clerk `/account` tab portal** (`src/pages/Account.tsx` + `components/portal/*`) — API-stubbed

**Recommendation:** Treat dedicated role routes as the production UX. Keep `/account` only if Clerk remains; otherwise retire or redirect to role dashboards.

### Admin supervision principle

All trade, finance, content, and compliance state changes that affect other roles or the public site require **Admin approval or action** before becoming authoritative. Role users submit requests; Admin progresses workflows.

```mermaid
flowchart TB
  subgraph public [PublicSite]
    Catalog[ProductsCatalog]
    InvestList[InvestmentListings]
    News[TradeNews]
    Contact[ContactForms]
  end
  subgraph roles [RolePortals]
    Buyer[Buyer]
    Supplier[Supplier]
    Investor[Investor]
  end
  Admin[AdminSupervision]
  Buyer -->|RFQ_Order_Checkout| Admin
  Supplier -->|Offers| Admin
  Investor -->|Deposit_Withdraw_Invest| Admin
  Admin -->|Approve_Quote_Ship_Publish| Buyer
  Admin -->|Approve_Reject_Rate| Supplier
  Admin -->|Approve_Funds_Projects| Investor
  Admin -->|CMS_Products_News| public
```

---

## 2. Current Frontend Inventory

**Legend — Data source**

| Code | Meaning |
|------|---------|
| S | Static / hardcoded in page |
| LS | `localStorage` (`admin-data`, `cms-data`, cart, local-auth) |
| Stub | `@workspace/api-client-react` stub (empty / no-op) |
| Ext | External `fetch` (news/FX APIs) |
| API | Must become Laravel-driven |

---

### 2.1 Public / marketing

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/` | `Home.tsx` | Landing (hero, products teaser, process, freight, CTA) | S + optional CMS | Yes (CMS) |
| `/products` | `Products.tsx` | Export product catalog | LS (`getProducts`) | Yes |
| `/products/:slug` | `ProductDetail.tsx` | Product detail, RFQ CTA | LS | Yes |
| `/invest` | `Invest.tsx` | Public investment listings | LS (`getInvestProjects`) | Yes |
| `/invest/:id` | `InvestDetail.tsx` | Single investment detail | LS | Yes |
| `/wholesale` | `Marketplace.tsx` | Domestic wholesale catalog | LS (`imported-products-data`) | Yes |
| `/market-intelligence` | `MarketIntelligence.tsx` | Commodity / freight charts | S (+ Ext prices) | Partial |
| `/market-reports` | same | Alias | — | — |
| `/news` | `TradeNews.tsx` | Trade news feed | LS + Ext RSS | Yes |
| `/documents` | `Documents.tsx` | Trade document types checklist | S | CMS optional |
| `/ai` | `AiHub.tsx` | AI trade assistant templates | S | Optional later |
| `/about` | `About.tsx` | Company story | S / CMS | Yes (CMS) |
| `/company-profile` | `CompanyProfile.tsx` | Corporate profile | S / CMS | Yes (CMS) |
| `/certifications` | `Certifications.tsx` | Cert list | S | CMS optional |
| `/contact` | `Contact.tsx` | Contact form + FAQ | Stub form | Yes |
| `/export-terms` | `ExportTerms.tsx` | Incoterms / payment terms | S | CMS optional |
| `/privacy` | `PrivacyPolicy.tsx` | Legal | S | CMS optional |
| `/terms` | `TermsOfService.tsx` | Legal | S | CMS optional |

**Orphan (not routed):** `Freight.tsx`, legacy `Admin.tsx`.

---

### 2.2 Auth

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/sign-in` | `SignIn.tsx` or Clerk | Login + role redirect | LS / Clerk | Sanctum |
| `/sign-up` | `SignUp.tsx` or Clerk | Register buyer/supplier/investor | LS / Clerk | Sanctum |
| `/forgot-password` | `ForgotPassword.tsx` | Reset UI | Demo | Sanctum + mail |
| `/account` | `Account.tsx` / `LocalAccount.tsx` | Profile / KYC / portal tabs | Stub / LS | Sanctum + KYC |

---

### 2.3 Buyer portal (`BuyerPortalLayout`)

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/buyer/dashboard` | `BuyerDashboard.tsx` | KPIs, charts, recent activity | S | Yes |
| `/buyer/analytics` | `BuyerAnalytics.tsx` | Trade analytics | S | Yes |
| `/buyer/messages` | `BuyerMessages.tsx` | Messaging | S / mock | Yes |
| `/buyer/profile` | `BuyerProfile.tsx` | Personal profile | LS | Yes |
| `/buyer/company` | `BuyerCompanyProfile.tsx` | Company / trade prefs | LS | Yes |
| `/buyer/settings` | `BuyerSettings.tsx` | Security / notifications | S | Yes |
| `/buyer/catalogue` | `BuyerCatalogue.tsx` | B2B catalog + cart | S (duplicate seed) | Yes (unify with products) |
| `/buyer/cart` | `BuyerCart.tsx` | Cart | LS (`useCart`) | Yes |
| `/buyer/checkout` | `BuyerCheckout.tsx` | Place order | LS → `recordBuyerOrder` | Yes |
| `/buyer/order-confirmation` | `BuyerOrderConfirmation.tsx` | Success | LS | Yes |
| `/buyer/rfq` | `BuyerRFQ.tsx` | RFQ list + create | S list + LS submit | Yes |
| `/buyer/rfq/new` | same | Create RFQ | LS | Yes |
| `/buyer/quotations` | `BuyerQuotations.tsx` | Received quotes | LS | Yes |
| `/buyer/orders` | `BuyerOrders.tsx` | Order list | S + LS | Yes |
| `/buyer/repeat-orders` | `BuyerRepeatOrders.tsx` | Reorder | S | Yes |
| `/buyer/shipments` | `BuyerShipments.tsx` | Tracking | S / LS | Yes |
| `/buyer/documents` | `BuyerDocuments.tsx` | Trade docs | S | Yes |
| `/buyer/payments` | `BuyerPayments.tsx` | Trade finance history | S | Yes |

**Gap:** Buyer routes are **not** auth-guarded in the router today.

---

### 2.4 Supplier portal (`SupplierPortalLayout`)

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/supplier/dashboard` | `supplier/SupplierDashboard.tsx` | Offer stats | Mixed LS + S | Yes |
| `/supplier/submit-offer` | `SupplierSubmitOffer.tsx` | New offer form | LS `addSupplierOffer` | Yes |
| `/supplier/my-offers` | `SupplierMyOffers.tsx` | Own offers | LS | Yes |
| `/supplier/messages` | `SupplierMessages.tsx` | Messaging | Mock | Yes |
| `/supplier/profile` | `SupplierProfile.tsx` | Company profile | LS | Yes |
| `/supplier/settings` | `SupplierSettings.tsx` | Settings | S | Yes |
| `/supplier/procedure` | `SupplierProcedure.tsx` | How-it-works guide | S | Optional CMS |

---

### 2.5 Investor portal (`InvestPortalLayout`)

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/invest/dashboard` | `InvestDashboard.tsx` | Portfolio KPIs | S | Yes |
| `/invest/wallet` | `InvestWallet.tsx` | Balances | S + Ext FX | Yes |
| `/invest/containers` | `ContainerInvestments.tsx` | Container projects | S / LS | Yes |
| `/invest/markets` | `InvestMarkets.tsx` | Fruits & veg markets | S | Yes |
| `/invest/plant` | `InvestPlant.tsx` | Processing plant | S | Yes |
| `/invest/cold-storage` | `InvestColdStorage.tsx` | Cold storage | S | Yes |
| `/invest/domestic-trading` | `InvestDomesticTrading.tsx` | Domestic trading | S | Yes |
| `/invest/deposit` | `InvestDeposit.tsx` | Deposit request | LS | Yes |
| `/invest/withdraw` | `InvestWithdraw.tsx` | Withdrawal request | LS | Yes |
| `/invest/kyc` | `InvestKYC.tsx` | KYC upload / status | LS / Stub | Yes |
| `/invest/reports` | `InvestReports.tsx` | Performance reports | S | Yes |
| `/invest/profile` | `InvestProfile.tsx` | Profile | LS | Yes |
| `/invest/settings` | `InvestSettings.tsx` | Preferences | S | Yes |
| `/invest/notifications` | `InvestNotifications.tsx` | Inbox | S | Yes |

---

### 2.6 Admin panel (`AdminLayout`)

| Route | Page file | Purpose | Data today | → API |
|-------|-----------|---------|------------|-------|
| `/admin/dashboard` | `admin/AdminDashboard.tsx` | Executive KPIs | S mock | Yes |
| `/admin/users` | `AdminUsers.tsx` | Buyers / investors / suppliers / staff / roles | LS | Yes |
| `/admin/investments` | `AdminInvestments.tsx` | Investment project CRUD | LS | Yes |
| `/admin/finance` | `AdminFinance.tsx` | Deposits, withdrawals, txns, bank accounts | LS | Yes |
| `/admin/orders` | `AdminOrders.tsx` | Orders & RFQs | LS | Yes |
| `/admin/quotations` | `AdminQuotations.tsx` | FOB sheet + quote builder | LS | Yes |
| `/admin/shipments` | `AdminShipments.tsx` | Container / vessel tracking | LS | Yes |
| `/admin/products` | `AdminProducts.tsx` | Catalog CRUD / approvals | LS | Yes |
| `/admin/crm` | `AdminCRM.tsx` | Lead pipeline | LS | Yes |
| `/admin/compliance` | `AdminCompliance.tsx` | KYC + audit | LS | Yes |
| `/admin/support` | `AdminSupport.tsx` | Tickets | LS | Yes |
| `/admin/suppliers` | `AdminSuppliers.tsx` | Supplier offer center | LS | Yes |
| `/admin/trade-intelligence` | `AdminTradeIntelligence.tsx` | News / alerts / RSS | LS + Ext | Yes |
| `/admin/cms` | `AdminCMS.tsx` | Site content | LS `cms-data` | Yes |
| `/admin/reports` | `AdminReports.tsx` | Aggregated reports | LS | Yes |
| `/admin/security` | `AdminSecurity.tsx` | Security + access logs | LS / S | Yes |
| `/admin/settings` | `AdminSettings.tsx` | SEO, media, system settings | LS | Yes |

**Gap:** Admin routes are **not** role-guarded client-side today (URL-accessible).

---

## 3. Admin-Managed Dynamic Content

Content that must be managed by Admin and consumed by public or role UIs.

| Domain | Consumed by | Admin UI | Notes |
|--------|-------------|----------|-------|
| Site CMS (hero, stats, contact, company, footer, social) | Home, About, Contact, Footer | `/admin/cms`, Settings | Source: `cms-data.ts` `SiteSettings` |
| SEO meta / site name / tagline | Global | `/admin/settings` | Also `AdminSettings` in `admin-data` |
| Media library | CMS, products, news | Settings → Media | Upload → storage URL |
| Export products | `/products`, Buyer catalogue | `/admin/products` | Status: draft / pending / approved / rejected |
| Product FOB prices | Auto-quotations | `/admin/quotations` | `FobPrice` → `BuyerQuote` |
| Wholesale / imported products | `/wholesale` | Recommend Admin Products tab or dedicated CRUD | Today: `imported-products-data.ts` |
| Investment projects | `/invest`, investor portals | `/admin/investments` | Types: container, produce, plant (+ UI variants: cold storage, domestic) |
| Trade news articles | `/news` | `/admin/trade-intelligence` | Publish / approve before public |
| Bank accounts | Investor deposit page | `/admin/finance?tab=bank-accounts` | Receiving accounts for wires |
| Payment methods | Checkout / deposit | Settings | Enable/disable + priority |
| Certifications / FAQs / legal | Public pages | CMS pages or settings keys | Mostly static today — migrate |
| Platform flags | Registration, KYC required, investment open, maintenance | Settings | Gate UX + API |

### Homepage sections that should pull CMS / API

1. Hero (headline, CTAs, media)  
2. Stats strip  
3. Featured products  
4. Investment teaser  
5. Testimonials / milestones (recommend CMS collections)  
6. Contact / CTA form destination  
7. Footer tagline, links, social, WhatsApp number  

---

## 4. Role × Operations Matrix (Under Admin Supervision)

### 4.1 Guest / Public

| Operation | Admin involvement |
|-----------|-------------------|
| Browse approved products / investments / news | Admin publishes / approves content |
| Contact / newsletter / partner application | Admin reads in CRM / inbox |
| Register as buyer / supplier / investor | Admin may require KYC before full access |

---

### 4.2 Buyer

| Operation | Buyer can | Admin must |
|-----------|-----------|------------|
| Manage personal / company profile | Create/update | Optional verify company |
| Browse catalogue / cart | Yes | Maintain product catalog & prices |
| Submit RFQ | Create RFQ (`new`) | Review → quote / convert / expire |
| Request / receive quotation | Request; accept / reject | Build & send quote (FOB + freight etc.) |
| Place order (checkout) | Submit | Confirm → production → shipping → delivered |
| Repeat order | Request from history | Same order pipeline |
| View shipments | Read own | Update milestones / status |
| View / download trade documents | Read own | Upload / attach docs |
| View payments | Read own | Record / reconcile payments |
| Messages / support tickets | Create / reply | Assign / resolve |
| Analytics dashboard | Read own aggregates | N/A (computed from orders) |

**Buyer order statuses:** `pending` → `confirmed` → `production` → `shipping` → `delivered` | `cancelled`  
**RFQ statuses:** `new` → `quoted` → `converted` | `expired`  
**Quote statuses:** `pending_admin` → `sent` → `accepted` | `rejected` | `expired` | `draft`

---

### 4.3 Supplier

| Operation | Supplier can | Admin must |
|-----------|--------------|------------|
| Company profile | Update | Verify supplier |
| Submit product offer | Create (`pending`) | Approve / reject / hold; rate; notes |
| View own offers | Read | Status updates |
| Messages | Create / reply | Moderate / respond |
| Procedure guide | Read | Optionally edit CMS |

**Offer statuses:** `pending` → `approved` | `rejected` | `hold`

Approved offers may feed catalog or sourcing — Admin decides what becomes a sellable product.

---

### 4.4 Investor

| Operation | Investor can | Admin must |
|-----------|--------------|------------|
| View portfolio / wallet / reports | Read own | Maintain projects & ledger |
| Browse investment types | Read published projects | CRUD projects, funding status |
| Invest / allocate to project | Request allocation | Confirm funds & credit project |
| Deposit | Submit proof / amount | Approve / reject → credit wallet |
| Withdraw | Request | Review / approve / reject → debit |
| KYC upload | Submit docs | Approve / reject / review |
| Notifications | Read | System + admin-triggered events |
| Profile / settings | Update | Suspend if needed |

**Project statuses:** `funding` | `active` | `shipping` | `completed`  
**Deposit statuses:** `pending` → `approved` | `rejected`  
**Withdrawal statuses:** `pending` → `review` → `approved` | `rejected`  
**KYC statuses (user):** `pending` | `review` | `verified` | `rejected` | `suspended`

---

### 4.5 Admin (full supervision)

| Module | Operations |
|--------|------------|
| Users & roles | CRUD users; assign `admin` / `buyer` / `supplier` / `investor`; staff permissions; suspend / delete |
| KYC / AML | Approve / reject KYC; investigate AML alerts |
| Products | CRUD; approve catalog; media; specs; featured |
| FOB & quotations | Maintain FOB sheet; build / send quotes |
| Orders & RFQs | Status pipeline; convert RFQ → order |
| Shipments | Booking → in-transit → arrived → delivered; milestones |
| Supplier center | Review offers; notes; ratings |
| Investments | Project CRUD; raised amount; investor counts |
| Finance | Deposits / withdrawals / transactions / bank accounts |
| CRM | Lead stages; activities; segments |
| Support | Tickets; replies; escalation |
| CMS / SEO / Media | Site content; news publish; media uploads |
| Trade intelligence | Articles; RSS sources; alerts |
| Reports | Platform analytics |
| Security | Access / audit logs; security settings |
| Settings | Registration, KYC required, investment open, currency, notifications, maintenance |

---

### 4.6 Approval gates (critical path)

| Event | Submitted by | Blocked until Admin |
|-------|--------------|---------------------|
| Product visible publicly | Admin or supplier→product | `status = approved` |
| News visible | Admin / RSS ingest | `published = true` |
| Supplier offer usable | Supplier | Approve offer |
| Quotation to buyer | Buyer RFQ | Admin sends quote |
| Order progression | Buyer checkout | Confirm + status updates |
| Shipment updates | System / Admin | Milestone updates |
| Wallet credit | Investor deposit | Approve deposit |
| Wallet debit / payout | Investor withdraw | Approve withdrawal |
| Invest in project | Investor | Project active + funds approved |
| Full portal privileges | Any role | KYC verified (if `kycRequired`) |

---

## 5. Recommended Laravel Database Schema

Derived from `AdminUser`, `AdminProduct`, `AdminOrder`, `AdminRFQ`, `BuyerQuote`, `SupplierOffer`, `AdminInvestProject`, `AdminDeposit`, `AdminKYC`, `SiteSettings`, etc.

### 5.1 Entity relationship overview

```mermaid
erDiagram
  users ||--o| user_profiles : has
  users }o--}o roles : has
  roles }o--}o permissions : has
  users ||--o{ kyc_applications : submits
  users ||--o{ rfqs : creates
  users ||--o{ orders : places
  users ||--o{ deposits : requests
  users ||--o{ withdrawals : requests
  users ||--o| wallets : has
  users ||--o{ supplier_offers : submits
  users ||--o{ investments : allocates
  products ||--o{ product_specs : has
  products ||--o{ product_media : has
  products ||--o{ fob_prices : priced
  rfqs ||--o{ quotations : receives
  orders ||--o{ order_items : contains
  orders ||--o| shipments : ships
  shipments ||--o{ shipment_milestones : tracks
  investment_projects ||--o{ investments : funded_by
  wallets ||--o{ wallet_transactions : ledger
  support_tickets ||--o{ support_messages : has
  crm_leads ||--o{ crm_activities : has
```

---

### 5.2 Core auth / RBAC

#### `users`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string | fullName |
| email | string unique | |
| password | string | |
| phone | string nullable | |
| email_verified_at | timestamp nullable | |
| account_status | enum | `active`, `suspended`, `inactive` |
| remember_token | string nullable | |
| timestamps | | |

#### `roles`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| name | string unique | `admin`, `buyer`, `supplier`, `investor` |
| guard_name | string | `web` / `sanctum` |
| timestamps | | |

Use **spatie/laravel-permission** or equivalent pivot tables: `model_has_roles`, `role_has_permissions`, `permissions`.

#### `user_profiles`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| user_id | FK users | unique |
| company_name | string nullable | |
| country | string nullable | |
| avatar_url | string nullable | |
| trust_score | unsignedTinyInt default 0 | |
| dept | string nullable | staff |
| category | string nullable | supplier category |
| capacity | string nullable | supplier |
| rating | decimal nullable | supplier |
| meta | json nullable | extra prefs |
| timestamps | | |

#### Sanctum

- `personal_access_tokens` (package default)  
- For SPA: Sanctum stateful domains + CORS (see §8)

---

### 5.3 KYC / compliance

#### `kyc_applications`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| user_id | FK users | |
| type | enum | `individual`, `company` |
| country | string | |
| status | enum | `pending`, `review`, `approved`, `rejected` |
| risk | enum | `low`, `medium`, `high` |
| submitted_at | timestamp | |
| reviewed_by | FK users nullable | admin |
| reviewed_at | timestamp nullable | |
| notes | text nullable | |
| timestamps | | |

#### `kyc_documents`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| kyc_application_id | FK | |
| doc_type | string | passport, NTN, etc. |
| path | string | storage path |
| original_name | string | |
| timestamps | | |

#### `aml_alerts`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| user_id | FK users | |
| severity | enum | `high`, `medium`, `low` |
| type | string | |
| amount | decimal nullable | |
| details | text | |
| status | enum | `open`, `investigating`, `resolved` |
| flagged_at | timestamp | |
| timestamps | | |

#### `audit_logs`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| user_id | FK nullable | actor |
| action | string | |
| module | string | |
| ip | string nullable | |
| meta | json nullable | |
| created_at | timestamp | |

---

### 5.4 Catalog / trade operations

#### `categories`

| Column | Type |
|--------|------|
| id, name, slug, parent_id nullable, timestamps |

#### `products`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| category_id | FK nullable | |
| name | string | |
| slug | string unique | |
| sku | string unique | |
| status | enum | `draft`, `pending`, `approved`, `rejected` |
| short_description | text nullable | |
| description | longText nullable | |
| origin | string nullable | |
| fob | string / decimal | display or numeric |
| price | decimal nullable | |
| currency | string default `USD` | |
| min_order / moq | string nullable | |
| hs_code | string nullable | |
| lead_time | string nullable | |
| shelf_life | string nullable | |
| storage_instructions | text nullable | |
| incoterms | string nullable | |
| video_url | string nullable | |
| image_url | string nullable | cover |
| featured | boolean | |
| stock | string nullable | |
| certifications | json | array |
| payment_terms | json | |
| delivery_terms | json | |
| packaging_options | json | |
| export_markets | json | |
| created_by | FK users nullable | |
| timestamps | | softDeletes optional |

#### `product_specs`

| Column | Type |
|--------|------|
| id, product_id FK, label, value, sort_order |

#### `product_media`

| Column | Type |
|--------|------|
| id, product_id FK, url, type (`image`/`video`), sort_order |

#### `imported_products`

Wholesale marketplace (`/wholesale`) — similar to products with domestic-focused fields; or `products.channel` enum `export` | `wholesale`.

#### `fob_prices`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| product_id | FK nullable | or product name string |
| price_per_mt | decimal | USD FOB |
| updated_at | timestamp | |

#### `rfqs`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| buyer_id | FK users | |
| product_id | FK nullable | |
| product_name | string | snapshot |
| qty | string | |
| destination | string | |
| incoterm | string nullable | |
| status | enum | `new`, `quoted`, `converted`, `expired` |
| submitted_at | timestamp | |
| timestamps | | |

#### `quotations` (buyer quotes)

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| rfq_id | FK | |
| buyer_id | FK users | |
| product_name | string | |
| qty_mt | decimal | |
| incoterm | string | |
| destination | string | |
| payment_terms | string | |
| valid_until | date | |
| status | enum | `pending_admin`, `sent`, `accepted`, `rejected`, `draft`, `expired` |
| source | enum | `auto-fob`, `admin` |
| fob_unit_price | decimal | |
| freight | decimal default 0 | |
| insurance | decimal default 0 | |
| doc_fee | decimal default 0 | |
| notes | text nullable | |
| issued_at | timestamp nullable | |
| timestamps | | |

#### `orders`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| order_number | string unique | |
| buyer_id | FK users | |
| status | enum | `pending`, `confirmed`, `production`, `shipping`, `delivered`, `cancelled` |
| payment_status | string | |
| payment_method | string nullable | |
| total_value | decimal | |
| currency | string | |
| quotation_id | FK nullable | |
| placed_at | timestamp | |
| timestamps | | |

#### `order_items`

| Column | Type |
|--------|------|
| id, order_id FK, product_id nullable, product_name, qty, unit_price, line_total |

#### `carts` / `cart_items` (optional server-side)

| carts | user_id unique |
| cart_items | cart_id, product_id, qty |

#### `shipments`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| order_id | FK | |
| buyer_id | FK users | |
| product_snapshot | string | |
| vessel | string nullable | |
| container | string nullable | |
| origin | string | |
| destination | string | |
| shipping_line | string nullable | |
| etd | date nullable | |
| eta | date nullable | |
| status | enum | `pending`, `booking`, `in-transit`, `arrived`, `delivered` |
| current_milestone | string nullable | |
| timestamps | | |

#### `shipment_milestones`

| Column | Type |
|--------|------|
| id, shipment_id FK, label, occurred_at, notes nullable |

#### `trade_documents`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| order_id / shipment_id | FK nullable | |
| buyer_id | FK | |
| type | string | BL, invoice, COA, etc. |
| path | string | |
| timestamps | | |

---

### 5.5 Supplier

#### `supplier_offers`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| supplier_id | FK users | |
| category | string | |
| product_name | string | |
| origin | string | |
| specifications | text nullable | |
| available_qty | string | |
| price_fob | string / decimal | |
| incoterm | string nullable | FOB / DAP |
| price_unit | string nullable | MT / 40kg |
| moq | string | |
| lead_time | string | |
| packaging | string | |
| payment_terms | string | |
| certifications | json | |
| valid_until | date nullable | |
| hs_code | string nullable | |
| status | enum | `pending`, `approved`, `rejected`, `hold` |
| rating | tinyInt nullable | set by admin |
| images | json nullable | |
| submitted_at | timestamp | |
| timestamps | | |

#### `supplier_offer_notes`

| Column | Type |
|--------|------|
| id, supplier_offer_id FK, admin_id FK, text, created_at |

#### `supplier_ratings` (optional aggregate)

| Column | Type |
|--------|------|
| supplier_id FK unique, rating decimal, rated_by FK, updated_at |

---

### 5.6 Investor / finance

#### `investment_projects`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| title | string | |
| type | enum | `container`, `produce`, `plant`, `cold_storage`, `domestic_trading` |
| status | enum | `funding`, `active`, `shipping`, `completed` |
| target_amount | decimal | |
| raised_amount | decimal default 0 | |
| investors_count | unsignedInt default 0 | |
| roi_label | string nullable | |
| expected_return_pct | decimal nullable | |
| min_investment | decimal nullable | |
| max_investment | decimal nullable | |
| location / origin / destination | strings | |
| vessel, etd, eta, ports | nullable | |
| image_url, description | | |
| commodity, variety, container_type | nullable | |
| risk_level | enum | `low`, `medium`, `high` |
| funding_deadline | date nullable | |
| investment_period_days | int nullable | |
| meta | json nullable | |
| timestamps | | |

#### `investments`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| project_id | FK | |
| investor_id | FK users | |
| amount | decimal | |
| status | enum | `pending`, `active`, `completed`, `cancelled` |
| invested_at | timestamp | |
| timestamps | | |

#### `wallets`

| Column | Type |
|--------|------|
| id, user_id unique, currency default USD, available_balance, pending_balance, timestamps |

#### `wallet_transactions`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| wallet_id | FK | |
| type | string | deposit, withdrawal, investment, return, adjustment |
| amount | decimal | signed or direction enum |
| reference | string nullable | |
| status | enum | `completed`, `pending`, `rejected` |
| meta | json nullable | |
| timestamps | | |

#### `deposits`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| investor_id | FK users | |
| amount | decimal | |
| method | string | |
| reference | string | |
| status | enum | `pending`, `approved`, `rejected` |
| project_id | FK nullable | optional earmark |
| reviewed_by | FK nullable | |
| timestamps | | |

#### `withdrawals`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| investor_id | FK users | |
| amount | decimal | |
| bank_details | json / text | |
| reference | string | |
| status | enum | `pending`, `review`, `approved`, `rejected` |
| note | text nullable | |
| timestamps | | |

#### `bank_accounts` (company receiving)

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| bank_name | string | |
| account_title | string | |
| account_number | string | |
| iban / swift | nullable | |
| currency | string | |
| is_active | boolean | |
| instructions | text nullable | |
| timestamps | | |

---

### 5.7 CRM / support / messaging

#### `crm_leads`

| Column | Type |
|--------|------|
| id, name, country, value, product, contact, stage, owner_id nullable, timestamps |

#### `crm_activities`

| Column | Type |
|--------|------|
| id, lead_id FK, type, note, user_id FK, occurred_at |

#### `support_tickets`

| Column | Type | Notes |
|--------|------|-------|
| id | bigint PK | |
| user_id | FK | |
| user_type | enum | `buyer`, `investor`, `supplier` |
| subject | string | |
| priority | enum | `high`, `medium`, `low` |
| status | enum | `open`, `escalated`, `pending`, `resolved`, `closed` |
| assignee_id | FK nullable | |
| timestamps | | |

#### `support_messages`

| Column | Type |
|--------|------|
| id, ticket_id FK, user_id FK, body, is_admin boolean, created_at |

#### `conversations` / `messages`

Buyer–admin / supplier–admin threads (portal Messages pages).

| conversations | id, subject, created_by, participant roles |
| messages | id, conversation_id, sender_id, body, read_at, created_at |

#### `notifications`

| Column | Type |
|--------|------|
| id, user_id, type, title, body, data json, read_at nullable, created_at |

---

### 5.8 CMS / content / leads

#### `site_settings`

Key-value or single JSON row:

| key | value (json) | e.g. `hero`, `stats`, `contact`, `social`, `footer`, `company`, `registrations`, `seo` |

#### `news_articles`

| Column | Type | Notes |
|--------|------|-------|
| id, title, slug unique, category, content, excerpt, image_url, author, published_at, published boolean, tags json, timestamps |

#### `media_items`

| Column | Type |
|--------|------|
| id, url, type (`image`/`video`), title, tags json, uploaded_by, timestamps |

#### `contact_messages`

| Column | Type |
|--------|------|
| id, name, email, phone, subject, message, status, timestamps |

#### `newsletter_subscribers`

| Column | Type |
|--------|------|
| id, email unique, subscribed_at, unsubscribed_at nullable |

#### `partner_applications`

| Column | Type |
|--------|------|
| id, company, contact, email, type, payload json, status, timestamps |

#### `platform_settings` (flags)

| Column | Type | Notes |
|--------|------|-------|
| site_name, tagline, support_email, whatsapp | | |
| maintenance_mode, registration_open, kyc_required, investment_open | boolean | |
| currency, min_investment | | |
| payment_methods | json | |
| notification_prefs | json | |

---

### 5.9 Indexes & constraints (essentials)

- Unique: `users.email`, `products.slug`, `products.sku`, `orders.order_number`, `news_articles.slug`
- Index: `orders(buyer_id, status)`, `rfqs(buyer_id, status)`, `deposits(status)`, `withdrawals(status)`, `supplier_offers(supplier_id, status)`, `investments(investor_id, project_id)`, `shipments(order_id)`, `audit_logs(module, created_at)`
- Soft deletes optional on products, users (prefer `account_status` for users)

---

## 6. Laravel API Surface Outline

Base URL: `/api`  
Auth: Sanctum (`auth:sanctum`)  
Role middleware: `role:admin|buyer|supplier|investor`

### 6.1 Auth (public)

| Method | Endpoint | Action |
|--------|----------|--------|
| POST | `/api/register` | Register buyer/supplier/investor |
| POST | `/api/login` | Issue session/token |
| POST | `/api/logout` | Revoke |
| POST | `/api/forgot-password` | Email reset |
| POST | `/api/reset-password` | Reset |
| GET | `/api/me` | Current user + role + profile + kycStatus |

### 6.2 Public content

| Method | Endpoint | Action |
|--------|----------|--------|
| GET | `/api/products` | Approved products (filters) |
| GET | `/api/products/{slug}` | Detail |
| GET | `/api/investments` | Published projects |
| GET | `/api/investments/{id}` | Detail |
| GET | `/api/news` | Published articles |
| GET | `/api/wholesale/products` | Imported/wholesale |
| GET | `/api/cms/settings` | Public CMS payload |
| POST | `/api/contact` | Contact message |
| POST | `/api/newsletter` | Subscribe |
| POST | `/api/partner-applications` | Partner apply |

### 6.3 Buyer (`role:buyer`)

| Method | Endpoint | Maps to UI |
|--------|----------|------------|
| GET/PUT | `/api/buyer/profile` | Profile / company |
| GET | `/api/buyer/catalogue` | Catalogue |
| GET/POST/DELETE | `/api/buyer/cart` | Cart |
| POST | `/api/buyer/checkout` | Checkout |
| GET/POST | `/api/buyer/rfqs` | RFQ list / create |
| GET | `/api/buyer/quotations` | Quotations |
| POST | `/api/buyer/quotations/{id}/accept` | Accept quote |
| POST | `/api/buyer/quotations/{id}/reject` | Reject quote |
| GET | `/api/buyer/orders` | Orders |
| POST | `/api/buyer/orders/{id}/repeat` | Repeat order |
| GET | `/api/buyer/shipments` | Shipments |
| GET | `/api/buyer/documents` | Documents |
| GET | `/api/buyer/payments` | Payments |
| GET | `/api/buyer/analytics` | Dashboard analytics |
| GET/POST | `/api/buyer/messages` | Messages |
| GET/POST | `/api/buyer/tickets` | Support |

### 6.4 Supplier (`role:supplier`)

| Method | Endpoint | Maps to UI |
|--------|----------|------------|
| GET/PUT | `/api/supplier/profile` | Profile |
| GET | `/api/supplier/offers` | My offers |
| POST | `/api/supplier/offers` | Submit offer |
| GET/POST | `/api/supplier/messages` | Messages |
| GET | `/api/supplier/dashboard` | Stats |

### 6.5 Investor (`role:investor`)

| Method | Endpoint | Maps to UI |
|--------|----------|------------|
| GET | `/api/investor/dashboard` | Portfolio KPIs |
| GET | `/api/investor/wallet` | Wallet |
| GET | `/api/investor/projects` | Browse by type |
| POST | `/api/investor/projects/{id}/invest` | Allocate |
| POST | `/api/investor/deposits` | Deposit request |
| POST | `/api/investor/withdrawals` | Withdraw request |
| GET/POST | `/api/investor/kyc` | KYC |
| GET | `/api/investor/reports` | Reports |
| GET | `/api/investor/notifications` | Notifications |
| GET/PUT | `/api/investor/profile` | Profile / settings |

### 6.6 Admin (`role:admin`)

Prefix: `/api/admin/...`

| Area | Endpoints (resource style) |
|------|----------------------------|
| Dashboard | `GET /dashboard` |
| Users | `GET/POST/PUT/DELETE /users`, assign roles, suspend |
| Roles / permissions | `GET/PUT /roles`, `/permissions` |
| Products | full CRUD + status |
| FOB prices | `GET/PUT /fob-prices` |
| RFQs / orders / quotations | list + status + quote builder |
| Shipments | CRUD + milestones |
| Supplier offers | list + approve/reject/hold + notes + rate |
| Investments | project CRUD + status |
| Finance | deposits approve/reject, withdrawals, transactions, bank accounts |
| KYC / AML | approve/reject, alert status |
| CRM | leads + activities |
| Support | tickets + replies |
| CMS / media / news | settings + articles + uploads |
| Trade intel | articles, sources, alerts |
| Reports | aggregated |
| Settings / security | platform flags, audit logs |

### 6.7 UI action → API (compact matrix)

| UI action | API |
|-----------|-----|
| Sign up / Sign in | `POST /register`, `POST /login` |
| Admin approve product | `PATCH /admin/products/{id}` `{status:approved}` |
| Buyer submit RFQ | `POST /buyer/rfqs` |
| Admin send quote | `POST /admin/quotations` or `PATCH .../send` |
| Buyer accept quote | `POST /buyer/quotations/{id}/accept` |
| Buyer checkout | `POST /buyer/checkout` |
| Admin update order | `PATCH /admin/orders/{id}` |
| Supplier submit offer | `POST /supplier/offers` |
| Admin approve offer | `PATCH /admin/supplier-offers/{id}` |
| Investor deposit | `POST /investor/deposits` |
| Admin approve deposit | `POST /admin/deposits/{id}/approve` |
| Investor withdraw | `POST /investor/withdrawals` |
| Admin approve withdraw | `POST /admin/withdrawals/{id}/approve` |
| Investor KYC upload | `POST /investor/kyc` (+ multipart) |
| Admin approve KYC | `POST /admin/kyc/{id}/approve` |
| Update CMS hero | `PUT /admin/cms/settings` |
| Publish news | `POST /admin/news` or publish flag |

---

## 7. Frontend Integration Roadmap

### Phase 1 — Foundation
- Laravel Sanctum + CORS for React origin (Laragon / production domains)
- Replace `local-auth` login/register with real API
- Implement real hooks in `packages/api-client-react` (or Axios client)
- `GET /api/me` drives Navbar + portal redirects
- **Route guards** for `/admin/*`, `/buyer/*`, `/supplier/*`, `/invest/*` by role

### Phase 2 — Public dynamic content
- Products list/detail from API
- CMS settings for Home / About / Contact / Footer
- News publish pipeline
- Contact + newsletter endpoints

### Phase 3 — Buyer trade flow
- Catalogue unified with products API
- Cart + checkout → orders
- RFQ → Admin quote → accept → order
- Orders, shipments, documents, payments lists

### Phase 4 — Supplier
- Submit / list offers
- Admin Offer Center approvals
- Messaging

### Phase 5 — Investor & finance
- Projects CRUD (admin) + browse (investor)
- Wallet + deposits / withdrawals approval loop
- Invest allocation + reports
- Bank accounts from admin finance

### Phase 6 — Compliance & ops
- KYC upload + admin review
- AML / audit logs
- CRM + support tickets
- Dashboard KPIs from real aggregates (replace mocks)

### Phase 7 — Hardening
- Unify or remove Clerk `/account` portal
- Permissions for staff (beyond single admin role)
- File uploads (S3 / local disk) for KYC, media, trade docs
- i18n for portal strings
- Remove `admin-data` localStorage seeds from production builds

---

## 8. Gaps, Risks & CORS Notes

### Gaps in current frontend

| Issue | Impact | Fix |
|-------|--------|-----|
| Admin & buyer routes unguarded | Anyone can open URLs | Role middleware + React guards |
| Buyer catalogue duplicates product seed | Data drift | Single products API |
| Dashboard KPIs hardcoded | Misleading until API | Aggregate endpoints |
| Dual auth (Clerk vs local) | Integration complexity | Prefer Sanctum; optional Clerk JWT later |
| API client fully stubbed | Forms look wired but no-op | Replace stubs phase-by-phase |
| i18n incomplete on portals | Inconsistent UX | Translate portal nav/pages |

### CORS / Sanctum (Laravel)

For React on e.g. `http://localhost:5173` talking to `http://og-exports.test` (or Laragon vhost):

1. `config/cors.php` — allow frontend origin; `supports_credentials` true if cookie SPA  
2. `SANCTUM_STATEFUL_DOMAINS` — include frontend host  
3. `SESSION_DOMAIN` / `FRONTEND_URL` as needed  
4. Frontend Axios/fetch: `withCredentials: true` for cookie mode, or `Authorization: Bearer` for token mode  
5. After each env/proxy change, verify a sample `GET /api/me` from the browser (no CORS error)

### Security

- Never ship seeded admin passwords from `local-auth.tsx` to production  
- All approval actions server-side only  
- Rate-limit login, contact, deposit submissions  
- Store KYC files privately (not public disk)

---

## 9. Source File Reference (frontend)

| Concern | Primary files |
|---------|---------------|
| Routes | `src/App.tsx` |
| Local auth / roles | `src/lib/local-auth.tsx`, `src/lib/use-safe-auth.ts` |
| Admin data model | `src/lib/admin-data.ts` |
| CMS model | `src/lib/cms-data.ts` |
| Product seed | `src/data/products.ts` |
| Investment seed | `src/data/investments.ts` |
| API stubs | `packages/api-client-react/src/index.ts` |
| Admin nav | `src/components/admin/AdminLayout.tsx` |
| Buyer nav | `src/components/buyer/BuyerPortalLayout.tsx` |
| Supplier nav | `src/components/supplier/SupplierPortalLayout.tsx` |
| Investor nav | `src/components/invest/InvestPortalLayout.tsx` |

---

## 10. Document History

| Version | Date | Notes |
|---------|------|-------|
| 1.0 | 2026-07-18 | Initial implementation blueprint from React UI analysis |
| 1.1 | 2026-07-18 | Laravel API + React wiring implemented (see §11) |

---

## 11. Implementation Status (2026-07-18)

### Runtime

| Service | URL |
|---------|-----|
| React frontend | `http://localhost:5000` |
| Laravel API | `http://localhost:8000` |
| Database | MySQL/MariaDB `ogexport_db` |

### Demo accounts (password for all: `Password@123`)

| Role | Email | Redirect |
|------|-------|----------|
| Admin | `ogadmin@ogexports.com` | `/admin/dashboard` |
| Buyer | `buyer@ogexports.com` | `/buyer/dashboard` |
| Supplier | `supplier@ogexports.com` | `/supplier/dashboard` |
| Investor | `investor@ogexports.com` | `/invest/dashboard` |

### What was implemented

- Laravel Sanctum SPA auth + Spatie roles (`admin`, `buyer`, `supplier`, `investor`)
- CORS credentials for `http://localhost:5000`
- Full domain schema + seeders (7 products with prices/images, CMS, investments, bank account, demo ops)
- **171** API routes covering public, admin, buyer, supplier, investor
- Frontend API client (`src/lib/api.ts`) + Sanctum CSRF
- `local-auth` replaced with Laravel login/register
- Role guards on all portal routes in `App.tsx`
- Public products listing/detail from API with pagination/filters
- Buyer catalogue unified with products API
- `admin-data.ts` / `cms-data.ts` bridged to Laravel admin/public APIs
- Contact / newsletter / partner hooks wired to API
- Pest tests: `tests/Feature/AuthApiTest.php` (6 passing)

### Commands

```bash
# Backend
cd D:\laragon\www\OGExport\laravel_api
php artisan serve --host=127.0.0.1 --port=8000
# (ensure MariaDB is running; create DB ogexport_db if needed)
php artisan migrate:fresh --seed

# Frontend
cd D:\laragon\www\OGExport\og_frontend
pnpm install
pnpm dev
```

### Known limitations / next polish

- Some investor category pages still show decorative mock KPIs alongside API project lists
- Market intelligence live commodity feeds remain client-side external APIs
- Playwright full browser E2E suite not yet added (manual + API smoke verified)
- Product images currently use mirrored remote `ogexports.co` URLs stored in DB

---

*This document is the single reference for implementing Laravel APIs and replacing localStorage/mocks. Update it when product scope or roles change.*
