# OG Exports

Pakistan's premier B2B agricultural trade platform — connecting verified international buyers, domestic wholesale buyers, suppliers, and investors globally.

## Stack

- **Frontend**: React 19 + TypeScript, Vite 6, TailwindCSS v4, Wouter (routing)
- **Auth**: Clerk (optional) with local-auth fallback
- **UI**: Radix UI + shadcn/ui components
- **i18n**: i18next (11 languages: EN, UR, ZH, RU, AR, TR, FR, DE, ES, IT, PT)
- **Package manager**: pnpm (workspace monorepo)

## How to run

```
pnpm run dev
```

The workflow "Start application" handles this automatically on port 5000.

## Key pages

| Route | Description |
|---|---|
| `/` | Homepage — cinematic hero, products, global markets, milestones, testimonials |
| `/products` | Export product catalog with search/filter |
| `/wholesale` | Pakistan Wholesale Marketplace (domestic B2B) |
| `/invest` | Investment opportunities portal |
| `/about` | Company overview |
| `/company-profile` | Full company profile |
| `/contact` | Contact form + FAQ |
| `/news` | Trade news |
| `/market-intelligence` | Market intelligence reports |
| `/freight` | Freight forwarding services |
| `/account/*` | Authenticated user portal (buyer/supplier/investor) |
| `/buyer/dashboard` | Dedicated buyer portal |
| `/invest/dashboard` | Investor portal |
| `/admin/*` | Super admin dashboard (all admin pages) |
| `/admin/suppliers` | Internal Supplier Offer Center (confidential) |

## Business rules (enforced in code)

- **Buyer/Supplier separation**: Suppliers never see buyer identities, orders, or pricing negotiations
- **Supplier portal** (`/account/*` with `accountType=supplier`): Restricted to `overview`, `my-offers` (own offer status only), `profile`, `support`, `notifications` — no access to orders/contracts/invoices/shipments
- **Admin Supplier Offer Center** (`/admin/suppliers`): Internal-only — admin can see all supplier offers, compare, approve/reject/hold, add notes, rate suppliers. Buyer info never exposed.
- **Pakistan Wholesale Marketplace** (`/wholesale`): OG Exports selling bulk products to domestic wholesale buyers — NOT a supplier directory

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `PORT` | Yes | Dev server port (set to `5000` in `.replit`) |
| `BASE_PATH` | Yes | URL base path (set to `/` in `.replit`) |
| `VITE_CLERK_PUBLISHABLE_KEY` | No | Clerk publishable key — app falls back to local auth if absent |
| `VITE_CLERK_PROXY_URL` | No | Clerk proxy URL (optional, used when Clerk is enabled) |

## Workspace packages

Three internal packages live in `packages/` — these are **stubs** created during import setup because the originals were not included in the uploaded zip:

| Package | Purpose |
|---|---|
| `packages/api-client-react` | React Query hooks for the backend API |
| `packages/api-zod` | Zod schemas / TypeScript types shared with the API |
| `packages/object-storage-web` | File upload hook (wraps Uppy + S3) |

All hooks return empty/undefined data and accept optional query options without TypeScript errors. Replace with real implementations once the backend API is available.

## SEO

- `index.html` — comprehensive meta tags (title, description, keywords, OG, Twitter Card)
- `public/robots.txt` — search engine crawl rules (admin/account routes excluded)
- `public/sitemap.xml` — all public pages listed with priority/changefreq
- `src/hooks/use-page-title.ts` — per-page title/description updater (applied to Products, About, Wholesale, Contact)

## Data layer (localStorage mock)

Admin pages use `src/lib/admin-data.ts` for localStorage-backed persistence:
- Supplier offers: `getSupplierOffers()`, `updateSupplierOffer()`, `addOfferNote()`, `rateSupplier()`
- Seed data: 6 realistic supplier offers across Rice, Grains, Sesame, Mangoes, Spices categories

## User preferences

_No preferences recorded yet._
