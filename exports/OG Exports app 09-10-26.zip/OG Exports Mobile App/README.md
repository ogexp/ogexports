# OG Exports Investor Mobile

Current Expo mobile app source bundle. This ZIP is source code, not an installable APK or AAB.

## Included

- The investor mobile app, screens, components, assets, app configuration, and tests.
- The shared generated API client required by the mobile app.
- Workspace manifests and the current lockfile.

## Excluded

- `node_modules`, Expo caches, static preview output, local environment files, and signing keys.
- The generated Android native project; Expo recreates native project files from `app.json` during its build flow.

## Requirements

- Node.js 20 or newer
- pnpm

## Install and run

From the extracted folder:

```sh
pnpm install --frozen-lockfile
EXPO_PUBLIC_API_BASE_URL=https://api.ogexports.co pnpm --filter @workspace/mobile exec expo start
```

The app requires the external OG Exports API for sign-in and investor data. The source archive does not include backend data or production signing credentials.
