# OG Exports Investor App

This archive contains the editable Expo mobile-app source, app assets, tests, and the generated OG Exports API client package. It is source code, not a prebuilt APK or IPA. The OG Exports backend/API is not included.

## Requirements

- Node.js and npm
- Android Studio for local Android builds, or Xcode on macOS for local iOS builds

## Install and run

```sh
npm install
npm run start
```

Use Expo Go to preview the app where supported, or use the native build commands below.

```sh
npm run android
npm run ios
npm run web
```

## Connect to the OG Exports API

Set the API base URL in the app's Settings, or provide `EXPO_PUBLIC_API_BASE_URL` in the build environment. Use the API server origin (for example, `https://api.example.com`), not an account token. The app uses its existing email/password and verification flows to authenticate with the API.

## Checks

```sh
npm run test
npm run typecheck
```

Native device builds require the corresponding platform toolchain. The EAS project identifier can be supplied with `EXPO_PUBLIC_EAS_PROJECT_ID` when configuring an EAS build.
