# OG Exports Investor App

This archive contains the editable Expo mobile-app source, app assets, tests, the branded OG Exports launch splash, and the generated OG Exports API client package. It is source code, not a prebuilt APK or IPA. The OG Exports backend/API is not included.

## Install and run

```sh
npm install
npm run start
```

Use Expo Go to preview the app where supported, or use the native build commands below.

```sh
npm run android
npm run ios
npm run web
```

## Connect to the OG Exports API

Set the API base URL in the app's Settings, or provide `EXPO_PUBLIC_API_BASE_URL` in the build environment. Use the API server origin (for example, `https://api.example.com`), not an account token.

## Checks

```sh
npm run test
npm run typecheck
```

Native device builds require the corresponding platform toolchain. The official app name and native splash are applied when a native build is generated and installed. The EAS project identifier can be supplied with `EXPO_PUBLIC_EAS_PROJECT_ID` when configuring an EAS build.
