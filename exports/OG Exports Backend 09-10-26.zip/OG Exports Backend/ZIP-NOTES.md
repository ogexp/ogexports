# OG Exports Backend Source ZIP

This is the Laravel backend source from the supplied OG Exports archive. It includes application code, routes, migrations, seeders, tests, Composer/npm manifests and lockfiles, and public product images.

For safety, this source export omits all `.env` files, local Postman settings, the local SQLite database, user uploads and generated reports, runtime storage contents, logs, compiled build output, and installed dependencies. Configure the environment locally and install dependencies from `composer.lock` and `package-lock.json` before running it.
