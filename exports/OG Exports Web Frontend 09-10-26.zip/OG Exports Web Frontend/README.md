# OG Exports Web Frontend

Source archive for the current OG Exports web frontend. The Laravel backend is not included.

## Included

- The complete web frontend artifact, screens, components, tests, and public images/videos.
- The shared API client source required by the workspace dependency.
- Workspace package manifests and the current pnpm lockfile.

## Excluded

- `.env` files, credentials, `node_modules`, generated `dist` output, and local build caches.

## Requirements and commands

Use Node.js and pnpm from the extracted folder:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/og-container-admin run dev
```

To build or typecheck the frontend:

```sh
pnpm --filter @workspace/og-container-admin run build
pnpm --filter @workspace/og-container-admin run typecheck
```

The frontend connects to the existing OG Exports API; configure its API address through the deployment environment. No backend data or credentials are included.
