# OG Exports Investor Mobile

Source archive for the Expo mobile app. This is not an installable APK/IPA.

## Requirements

- Node.js 20 or newer
- pnpm 10.26.1

## Install and run

From this folder:

```sh
pnpm install --frozen-lockfile
EXPO_PUBLIC_API_BASE_URL=https://api.ogexports.co pnpm start
```

On PowerShell, set the API address first with:

```powershell
$env:EXPO_PUBLIC_API_BASE_URL = "https://api.ogexports.co"
pnpm start
```

The archive includes the mobile app and its shared generated API client. It excludes Replit credentials, `.env` files, dependency folders, and generated Expo preview/build output. The app requires the external OG Exports API for sign-in and investor data.
