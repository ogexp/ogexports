# OG Exports App

Yeh archive OG Exports mobile app ka source project hai. Is mein Expo app aur us ka shared API client shamil hain; OG Exports Laravel API server is ZIP ka hissa nahi hai.

## Chalane ke liye

Zaroorat: Node.js aur pnpm.

```sh
pnpm install
pnpm --filter @workspace/mobile exec expo start --port 8081
```

App mein API server ka address maujooda Settings screen se configure karein. Login screen par API address set karne ki zaroorat nahi.
